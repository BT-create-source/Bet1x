<?php
/**
 * Centralised, validated runtime configuration.
 *
 * Port of backend/config.js. Same variable names, same defaults, same fail-fast behaviour: in
 * production the process refuses to serve when a security-critical value is missing or is still a
 * development placeholder.
 *
 * There is no dotenv package on shared hosting, so .env is parsed here by hand. Values already
 * present in the real environment (cPanel's "Environment Variables", or SetEnv in .htaccess) win
 * over the file, matching how dotenv behaves.
 */

if (defined('BET1X_CONFIG_LOADED')) { return; }
define('BET1X_CONFIG_LOADED', true);

// -------------------------------------------------------------------------------------------------
// .env loading
// -------------------------------------------------------------------------------------------------

/**
 * Parse a .env file into an array. Deliberately minimal — KEY=VALUE, # comments, optional quotes.
 * No variable interpolation, because the Node build's dotenv did not do it either.
 */
function bet1x_parse_env($path) {
    $out = [];
    if (!is_readable($path)) return $out;
    foreach (file($path, FILE_IGNORE_NEW_LINES) as $line) {
        $line = trim($line);
        if ($line === '' || $line[0] === '#') continue;
        $eq = strpos($line, '=');
        if ($eq === false) continue;
        $key = trim(substr($line, 0, $eq));
        $val = trim(substr($line, $eq + 1));
        if (strlen($val) >= 2) {
            $first = $val[0]; $last = substr($val, -1);
            if (($first === '"' && $last === '"') || ($first === "'" && $last === "'")) {
                $val = substr($val, 1, -1);
            }
        }
        if ($key !== '') $out[$key] = $val;
    }
    return $out;
}

$BET1X_ENV_FILE = array_merge(
    bet1x_parse_env(dirname(__DIR__) . '/.env'),   // repo-root fallback, same as config.js
    bet1x_parse_env(__DIR__ . '/.env')             // php-backend/.env wins
);

/** Real environment first, then the .env file, then the supplied default. */
function env_get($name, $default = null) {
    global $BET1X_ENV_FILE;
    $v = getenv($name);
    if ($v === false || $v === '') {
        $v = isset($BET1X_ENV_FILE[$name]) ? $BET1X_ENV_FILE[$name] : null;
    }
    if ($v === null || $v === '') return $default;
    return $v;
}

function env_bool($name, $default) {
    $v = env_get($name, null);
    if ($v === null) return $default;
    return in_array(strtolower((string)$v), ['1', 'true', 'yes', 'on'], true);
}

function env_num($name, $default) {
    $v = env_get($name, null);
    if ($v === null) return $default;
    return is_numeric($v) ? (float)$v : $default;
}

function env_list($name) {
    $v = env_get($name, '');
    if ($v === null || $v === '') return [];
    $parts = array_map('trim', explode(',', (string)$v));
    return array_values(array_filter($parts, function ($s) { return $s !== ''; }));
}

// -------------------------------------------------------------------------------------------------
// Resolved configuration
// -------------------------------------------------------------------------------------------------

$fatal = [];

$NODE_ENV      = env_get('NODE_ENV', 'development');
$IS_PRODUCTION = ($NODE_ENV === 'production');

// --- Secrets ---
// APP_SECRET is the only thing standing between a forged auth token and someone else's wallet.
//
// PORT NOTE: the Node build generated a random per-boot secret in development. PHP has no "boot" —
// a fresh random value on every request would invalidate every token instantly — so development
// falls back to a FIXED, obviously-fake development secret instead. Production still refuses to
// start without a real one. Set the SAME APP_SECRET the Node build used and every token already
// issued to a player stays valid across the cutover.
$APP_SECRET = (string) env_get('APP_SECRET', '');
if ($APP_SECRET === '') {
    if ($IS_PRODUCTION) {
        $fatal[] = 'APP_SECRET is required when NODE_ENV=production. Generate one with:  php -r "echo bin2hex(random_bytes(48));"';
    }
    $APP_SECRET = 'bet1x-development-only-secret-do-not-use-in-production-0000000000';
} elseif (strlen($APP_SECRET) < 32) {
    $fatal[] = 'APP_SECRET must be at least 32 characters of high-entropy random data.';
}

// --- Admin credentials ---
$ADMIN_USERNAME          = (string) env_get('ADMIN_USERNAME', 'admin');
$ADMIN_PASSWORD_HASH     = (string) env_get('ADMIN_PASSWORD_HASH', '');
$ADMIN_PASSWORD_PLAINTEXT = (string) env_get('ADMIN_PASSWORD', '');

$SUPERADMIN_USERNAME          = (string) env_get('SUPERADMIN_USERNAME', 'superadmin');
$SUPERADMIN_PASSWORD_HASH     = (string) env_get('SUPERADMIN_PASSWORD_HASH', '');
$SUPERADMIN_PASSWORD_PLAINTEXT = (string) env_get('SUPERADMIN_PASSWORD', '');

// No longer used (kept so an old .env still loads): the admin console has no entry point to the super
// admin page any more — that page is reached only by typing its unlinked address.
$SUPERADMIN_ACCESS_TOKEN = (string) env_get('SUPERADMIN_ACCESS_TOKEN', '');

// --- Phone verification (Fast2SMS) ---------------------------------------------------------------
//
// PHONE_VERIFICATION_REQUIRED is the master switch. With it false nothing changes: signup ignores
// phone verification and no signup SMS is sent, so the feature can be deployed dark and turned on once the
// SMS account is confirmed working.
$PHONE_VERIFICATION_REQUIRED = env_bool('PHONE_VERIFICATION_REQUIRED', false);

// The Fast2SMS key. Server-side only — it is never sent to the browser, because anyone holding it
// can send SMS billed to this account.
$FAST2SMS_API_KEY = (string) env_get('FAST2SMS_API_KEY', '');

// Which Fast2SMS route the account is provisioned for. India requires DLT registration for
// transactional SMS, and which routes a given key may use depends on that registration, so this is
// configuration rather than a hardcoded choice:
//   'otp' — the OTP route, message is the code itself via variables_values
//   'dlt' — a DLT-approved template, needs FAST2SMS_MESSAGE_ID and a registered sender id
//   'q'   — the quick/promotional route
$FAST2SMS_ROUTE      = (string) env_get('FAST2SMS_ROUTE', 'otp');
$FAST2SMS_SENDER_ID  = (string) env_get('FAST2SMS_SENDER_ID', '');
$FAST2SMS_MESSAGE_ID = (string) env_get('FAST2SMS_MESSAGE_ID', '');

// A production boot with verification switched on but no key would accept signups it can never send
// a code for, so refuse to start rather than discover it from customers who cannot register.
if ($IS_PRODUCTION && $PHONE_VERIFICATION_REQUIRED && $FAST2SMS_API_KEY === '') {
    $fatal[] = 'PHONE_VERIFICATION_REQUIRED is on but FAST2SMS_API_KEY is empty. No signup could '
             . 'complete, because no verification code could be sent.';
}

// --- Email verification (SMTP) --------------------------------------------------------------------
//
// The replacement verification channel while phone/SMS (Fast2SMS) is parked — see the note on
// PHONE_VERIFICATION_REQUIRED above. Same master-switch shape: off by default, ships dark, turned
// on only once SMTP_HOST/SMTP_USER/SMTP_PASSWORD are confirmed working. lib/mailer.php speaks SMTP
// directly to whichever server these point at (Gmail, Brevo's SMTP relay, or anything else that
// takes standard SMTP AUTH) — no third-party HTTP API, no library.
$EMAIL_VERIFICATION_REQUIRED = env_bool('EMAIL_VERIFICATION_REQUIRED', false);

$SMTP_HOST     = (string) env_get('SMTP_HOST', '');
$SMTP_PORT     = (int) env_num('SMTP_PORT', 587);
$SMTP_USER     = (string) env_get('SMTP_USER', '');
// For Gmail this MUST be a 16-character App Password (Google Account -> Security -> App
// Passwords — requires 2-Step Verification on the account), never the normal login password. For
// Brevo this is the SMTP key from the SMTP & API -> SMTP tab (not an API key from the API Keys tab
// — those are for the HTTP API and Brevo's SMTP server will reject them).
$SMTP_PASSWORD = (string) env_get('SMTP_PASSWORD', '');
// The verified "From" address. Left blank, it defaults to SMTP_USER (correct for Gmail, where the
// authenticated account and the From address are always the same). Set it explicitly for a
// provider like Brevo, where the SMTP login can differ from the address you've verified for
// sending.
$SMTP_SENDER_EMAIL = (string) env_get('SMTP_SENDER_EMAIL', '');
$SMTP_SENDER_NAME  = (string) env_get('SMTP_SENDER_NAME', 'bet1x');

if ($IS_PRODUCTION && $EMAIL_VERIFICATION_REQUIRED
    && ($SMTP_HOST === '' || $SMTP_USER === '' || $SMTP_PASSWORD === '')) {
    $fatal[] = 'EMAIL_VERIFICATION_REQUIRED is on but SMTP_HOST / SMTP_USER / SMTP_PASSWORD is '
             . 'empty. No signup could complete, because no verification code could be sent.';
}

// OTP behaviour, shared by both phone and email verification. The defaults are the abuse brakes;
// every send costs money at the provider, so these are not cosmetic.
$OTP_LENGTH                = max(4, min(8, (int) env_num('OTP_LENGTH', 6)));
$OTP_TTL_SECONDS           = (int) env_num('OTP_TTL_SECONDS', 300);            // code dies after 5 min
$OTP_MAX_ATTEMPTS          = (int) env_num('OTP_MAX_ATTEMPTS', 5);             // wrong guesses per code
$OTP_RESEND_COOLDOWN_SEC   = (int) env_num('OTP_RESEND_COOLDOWN_SEC', 60);     // between two sends
$OTP_MAX_SENDS_PER_DAY     = (int) env_num('OTP_MAX_SENDS_PER_DAY', 8);        // per phone number / email

if ($IS_PRODUCTION) {
    if ($ADMIN_PASSWORD_HASH === '') {
        $fatal[] = 'ADMIN_PASSWORD_HASH is required when NODE_ENV=production. Generate one with:  php -r "echo password_hash(\'your-password\', PASSWORD_BCRYPT, [\'cost\'=>12]);"';
    }
    if ($ADMIN_PASSWORD_PLAINTEXT !== '') {
        $fatal[] = 'ADMIN_PASSWORD (plaintext) must not be used in production — set ADMIN_PASSWORD_HASH instead.';
    }
    if ($SUPERADMIN_PASSWORD_PLAINTEXT !== '') {
        $fatal[] = 'SUPERADMIN_PASSWORD (plaintext) must not be used in production — set SUPERADMIN_PASSWORD_HASH instead.';
    }
} else {
    if ($ADMIN_PASSWORD_HASH === '' && $ADMIN_PASSWORD_PLAINTEXT === '') {
        $ADMIN_PASSWORD_PLAINTEXT = 'admin123';
    }
    if ($SUPERADMIN_PASSWORD_HASH === '' && $SUPERADMIN_PASSWORD_PLAINTEXT === '') {
        $SUPERADMIN_PASSWORD_PLAINTEXT = 'SuperAdmin@2026!';
    }
}

// --- Database ---
// DATABASE_URL keeps the same name and URL shape the Node build used (postgresql://). Discrete
// DB_* variables are also accepted because cPanel's own PostgreSQL database wizard hands those
// out separately.
//
// DB_DRIVER picks the engine: 'pgsql' (the default) or 'mysql' (MySQL 8 / MariaDB 10.3+, for hosts
// such as GoDaddy whose cPanel only offers MySQL). Left unset, it follows a mysql:// DATABASE_URL or
// DB_PORT=3306. The two schemas are sql/schema-postgres.sql (+ migrations) and sql/schema-mysql.sql.
$DATABASE_URL = (string) env_get('DATABASE_URL', '');
$DB_DRIVER = strtolower(trim((string) env_get('DB_DRIVER', '')));
if ($DB_DRIVER === '') {
    if (preg_match('#^(mysql|mariadb)://#i', $DATABASE_URL)) $DB_DRIVER = 'mysql';
    elseif ((string) env_get('DB_PORT', '') === '3306') $DB_DRIVER = 'mysql';
    else $DB_DRIVER = 'pgsql';
}
if (in_array($DB_DRIVER, ['postgres', 'postgresql', 'pg'], true)) $DB_DRIVER = 'pgsql';
if ($DB_DRIVER === 'mariadb') $DB_DRIVER = 'mysql';
if ($DB_DRIVER !== 'pgsql' && $DB_DRIVER !== 'mysql') {
    $fatal[] = 'DB_DRIVER must be "pgsql" or "mysql" (got "' . $DB_DRIVER . '").';
    $DB_DRIVER = 'pgsql';
}
$DB = [
    'driver' => $DB_DRIVER,
    'host' => (string) env_get('DB_HOST', $DB_DRIVER === 'mysql' ? 'localhost' : '127.0.0.1'),
    'port' => (int) env_num('DB_PORT', $DB_DRIVER === 'mysql' ? 3306 : 5432),
    'name' => (string) env_get('DB_NAME', ''),
    'user' => (string) env_get('DB_USER', ''),
    'pass' => (string) env_get('DB_PASS', ''),
];
if ($DATABASE_URL !== '') {
    $p = parse_url($DATABASE_URL);
    if ($p !== false) {
        if (!empty($p['host'])) $DB['host'] = $p['host'];
        if (!empty($p['port'])) $DB['port'] = (int)$p['port'];
        if (!empty($p['user'])) $DB['user'] = rawurldecode($p['user']);
        if (isset($p['pass'])) $DB['pass'] = rawurldecode($p['pass']);
        if (!empty($p['path'])) $DB['name'] = ltrim($p['path'], '/');
    }
}
if ($IS_PRODUCTION && $DB['name'] === '') {
    $fatal[] = 'DATABASE_URL (or DB_NAME/DB_USER/DB_PASS) is required when NODE_ENV=production.';
}

$ALLOW_JSON_FALLBACK = env_bool('ALLOW_JSON_FALLBACK', !$IS_PRODUCTION);

// --- HTTP ---
$TRUST_PROXY  = (int) env_num('TRUST_PROXY', 0);
$CORS_ORIGINS = env_list('CORS_ORIGINS');
$FORCE_HTTPS  = env_bool('FORCE_HTTPS', $IS_PRODUCTION);

// --- Product rules ---
$SIGNUP_BONUS            = env_num('SIGNUP_BONUS', $IS_PRODUCTION ? 0 : 2000);
$ALLOW_AUTO_USER_CREATION = env_bool('ALLOW_AUTO_USER_CREATION', false);
$BCRYPT_ROUNDS           = (int) env_num('BCRYPT_ROUNDS', 12);
$SESSION_TTL_MS          = (int) round(env_num('SESSION_TTL_HOURS', 24 * 7) * 3600 * 1000);
$MIN_BET                 = env_num('MIN_BET', 1);
// The largest single stake, across Aviator, Colour Prediction and Mines (the crash games keep their
// own tighter per-game caps). This is the main brake on short-term swings: one ₹1,00,000 Aviator
// bet at 50x is a ₹50 lakh payout, so the house's whole day can turn on one lucky round. ₹10,000
// keeps any single round's exposure to a level a day's normal volume absorbs. Raise it in .env only
// with the bankroll to cover the matching win.
$MAX_BET                 = env_num('MAX_BET', 10000);
$MIN_WITHDRAWAL          = env_num('MIN_WITHDRAWAL', 100);
// Rupees per coin: the one conversion rule for turning coins into money. The cashier has always
// worked 1:1 (a ₹100 deposit credits 100 coins, a 100-coin withdrawal pays ₹100), which is the
// default. The sub-admin system reads ONLY this value to show the rupee equivalent of a withdrawal
// request and to suggest a payout, so the figure can never disagree between pages. Changing it
// away from 1 also means re-labelling the cashier page, which still states amounts in INR.
$COIN_RUPEE_RATE         = env_num('COIN_RUPEE_RATE', 1);
if (!($COIN_RUPEE_RATE > 0)) $COIN_RUPEE_RATE = 1;

// --- Testing switches ---
$DISABLE_RATE_LIMITS = env_bool('DISABLE_RATE_LIMITS', false);
if ($IS_PRODUCTION && $DISABLE_RATE_LIMITS) {
    $fatal[] = 'DISABLE_RATE_LIMITS must never be set when NODE_ENV=production — it turns off login brute-force protection.';
}

// --- House-edge engine ---
$AVIATOR_SMART_CRASH    = env_bool('AVIATOR_SMART_CRASH', true);
$AVIATOR_HIGH_STAKE_REF = env_num('AVIATOR_HIGH_STAKE_REF', 1000);
// A hard ceiling on what one Aviator bet can pay, the same backstop the crash games (Astronaut,
// Tower Rush, Chicken Road) already carry. The crash point is capped at 50x and MAX_BET caps the
// stake, so this only bites on an operator override or a raised MAX_BET — it is the last guard
// against one round paying out more than the float can cover.
$AVIATOR_MAX_WIN        = env_num('AVIATOR_MAX_WIN', 1000000);

// Teen Patti pads any table short of 4 seats with randomly-named NPC fillers, and runs a background
// "organic traffic" engine that seats simulated players into rooms with nobody real in them at all,
// each room topped up only to its own configured ambient target rather than always to full capacity
// — see tp_room_bot_target() / tp_maybe_shuffle_room_bot_targets() in lib/botengine.php. Explicit
// product decision: on by default in every environment, including production, so the lobby always
// shows varied activity even with zero real players — set TEENPATTI_AUTO_BOT_FILL=false in .env to
// fall back to a real-players-only table (a round still starts fine with as few as 2 real players
// either way). This does not touch the separate "Admin" house seat used for rigging — see the
// bot-seat fallback in teenpatti.php's tp_start_round().
$TEENPATTI_AUTO_BOT_FILL = env_bool('TEENPATTI_AUTO_BOT_FILL', true);

// The house's cut ("admin profit") of every Teen Patti pot a player wins, in percent (0-20). Teen
// Patti pays the winner the whole pot, so this commission is the ONLY thing the house earns on a
// hand a player wins — raising it is the direct lever on Teen Patti profit. 10% is the top of what
// established Teen Patti apps charge; above that players notice losing a large slice of every pot.
// It is taken only from a real player's winnings, never from the house's own ("Admin") seat.
$TEENPATTI_COMMISSION_PCT = max(0.0, min(20.0, (float) env_num('TEENPATTI_COMMISSION_PCT', 10)));

// --- Monitoring ---
// How old the cron heartbeat may get before /api/ready reports the deployment as not-ready.
// The cron runs every minute, so 300s tolerates four consecutive missed runs before alerting —
// loose enough not to page on a single slow tick, tight enough to catch a genuinely dead cron
// while games are still recoverable. Set to 0 to disable the check.
$CRON_STALE_SECONDS = (int) env_num('CRON_STALE_SECONDS', 300);
// Optional: enables GET/POST /api/cron/tick (routes/cron.php) for hosts whose cron jobs do not run.
// Empty = that URL does not exist. It is a password: long and random, never reused.
$CRON_HTTP_KEY = (string) env_get('CRON_HTTP_KEY', '');
if ($CRON_HTTP_KEY !== '' && strlen($CRON_HTTP_KEY) < 32) {
    $fatal[] = 'CRON_HTTP_KEY must be at least 32 random characters (or left empty to disable /api/cron/tick).';
}

// --- Risk controls (php-backend/lib/riskcontrols.php) ---
// Registration carries no email confirmation and no KYC, and phone verification is off unless
// PHONE_VERIFICATION_REQUIRED is set above — so in the default configuration these are the only
// automated brakes on bonus farming and runaway cashout velocity. Each defaults OFF (0/false) so
// that an existing deployment and the test suites behave exactly as before; the production .env
// generated by tools/make-production-env.php turns all of them on.
$SIGNUP_MAX_PER_IP_PER_DAY  = (int)   env_num('SIGNUP_MAX_PER_IP_PER_DAY', 0);
$WITHDRAWAL_DAILY_MAX       = (float) env_num('WITHDRAWAL_DAILY_MAX', 0);
$WITHDRAWAL_DAILY_COUNT_MAX = (int)   env_num('WITHDRAWAL_DAILY_COUNT_MAX', 0);
$WITHDRAWAL_REQUIRE_DEPOSIT = env_bool('WITHDRAWAL_REQUIRE_DEPOSIT', false);
// Play-through before cash-out: a player must have wagered at least this multiple of everything
// they ever deposited before a withdrawal is accepted (1 = "play your deposits once"). It stops
// money going straight in and back out — which is what made the referral commission (paid on every
// approved deposit) a loop: deposit into a second account, collect the inviter's 1.5-1.8%, withdraw,
// repeat. On by default in production; 0 turns it off.
$WITHDRAWAL_MIN_TURNOVER    = max(0.0, (float) env_num('WITHDRAWAL_MIN_TURNOVER', $IS_PRODUCTION ? 1 : 0));

// A signup bonus that can be withdrawn without ever depositing is just free money handed to whoever
// scripts the registration form. Refuse to boot on that combination rather than discovering it in
// the payout queue.
if ($IS_PRODUCTION && $SIGNUP_BONUS > 0 && !$WITHDRAWAL_REQUIRE_DEPOSIT) {
    $fatal[] = 'SIGNUP_BONUS is greater than zero while WITHDRAWAL_REQUIRE_DEPOSIT is off. '
             . 'Unverified accounts could register in bulk and cash the bonus straight out. '
             . 'Either set SIGNUP_BONUS=0 or set WITHDRAWAL_REQUIRE_DEPOSIT=true.';
}

// --- Cricket (Your 11 / Boundary Baazi) ---
// Gated off for v1 and NOT ported: with this false, no cricket route exists at all, which is
// exactly what the Node build does with the flag off. When the games are ported for v2 this is the
// switch that turns them on, alongside deleting the [data-feature="cricket"] rule in
// assets/css/style.css. Setting it true today changes nothing, because there is nothing to mount.
$CRICKET_ENABLED = env_bool('CRICKET_ENABLED', false);
$FANTASY_ENABLED = env_bool('FANTASY_ENABLED', false);

// --- Production guard: simulated cricket must never take real money ---
// Without Roanuz keys the cricket feed falls back to a simulated league (CRICKET_SOURCE=mock), and
// FANTASY_SOURCE=mock serves canned fixtures. Both are right for development and fatal for a real-money
// site: players would stake on matches that never happened. In production a game whose data would be
// simulated is held OFF — routes not mounted, cron idle — and the reason is logged and reported by
// /api/health. Deliberately not a site-wide fail-fast: a missing cricket key must not take Aviator,
// the cashier and everything else down with it.
$CRICKET_SOURCE_RESOLVED = strtolower(trim((string) env_get('CRICKET_SOURCE', '')));
if (!in_array($CRICKET_SOURCE_RESOLVED, ['mock', 'roanuz', 'sportmonks'], true)) {
    $CRICKET_SOURCE_RESOLVED = (trim((string) env_get('ROANUZ_API_KEY', '')) !== '' && trim((string) env_get('ROANUZ_PROJECT_KEY', '')) !== '')
        ? 'roanuz' : 'mock';
}
// CRICKET_VIRTUAL=true is the operator's explicit opt-in to running the simulated league in production
// as real-money "Virtual Cricket": fictional teams, matches generated server-side from a secret key
// (lib/cricket-mock.php CricketSecureRng) and priced from the simulator's own model. Without it, the
// simulator stays a development tool and is refused in production as before.
$CRICKET_VIRTUAL = env_bool('CRICKET_VIRTUAL', false);
$CRICKET_BLOCKED = [];
$FANTASY_BLOCKED = [];
if ($IS_PRODUCTION) {
    if ($CRICKET_ENABLED) {
        if ($CRICKET_SOURCE_RESOLVED === 'mock' && !$CRICKET_VIRTUAL) {
            $CRICKET_BLOCKED[] = env_get('CRICKET_SOURCE', '') !== '' && strtolower((string) env_get('CRICKET_SOURCE')) === 'mock'
                ? 'CRICKET_SOURCE=mock (simulated matches) needs CRICKET_VIRTUAL=true to run in production.'
                : 'ROANUZ_API_KEY / ROANUZ_PROJECT_KEY are not set, so the feed would be simulated (set CRICKET_VIRTUAL=true to run Virtual Cricket).';
        }
        if ($CRICKET_SOURCE_RESOLVED === 'mock' && $CRICKET_VIRTUAL && strlen((string) env_get('CRICKET_VIRTUAL_SECRET', '')) < 32 && strlen($APP_SECRET) < 32) {
            $CRICKET_BLOCKED[] = 'Virtual Cricket needs a secret of at least 32 characters (CRICKET_VIRTUAL_SECRET or APP_SECRET), or its matches could be predicted.';
        }
        if ($CRICKET_SOURCE_RESOLVED === 'sportmonks' && trim((string) env_get('SPORTMONKS_API_TOKEN', '')) === '') {
            $CRICKET_BLOCKED[] = 'CRICKET_SOURCE=sportmonks but SPORTMONKS_API_TOKEN is not set, so no live ball could ever arrive.';
        }
        if ($CRICKET_SOURCE_RESOLVED === 'roanuz' && trim((string) env_get('ROANUZ_WEBHOOK_SECRET', '')) === '') {
            $CRICKET_BLOCKED[] = 'ROANUZ_WEBHOOK_SECRET is not set, so no live ball could ever arrive.';
        }
    }
    if ($FANTASY_ENABLED) {
        $fs = strtolower(trim((string) env_get('FANTASY_SOURCE', 'mock')));
        if ($fs === 'mock' || $fs === '') $FANTASY_BLOCKED[] = 'FANTASY_SOURCE=mock (canned fixtures) is not allowed in production; use FANTASY_SOURCE=feed.';
        elseif ($fs === 'feed' && $CRICKET_SOURCE_RESOLVED === 'mock' && !$CRICKET_VIRTUAL) $FANTASY_BLOCKED[] = 'FANTASY_SOURCE=feed but the cricket feed would be simulated (no Roanuz keys; set CRICKET_VIRTUAL=true for Virtual Cricket).';
    }
    foreach ($CRICKET_BLOCKED as $why) error_log('[bet1x-backend] Cricket held OFF: ' . $why);
    foreach ($FANTASY_BLOCKED as $why) error_log('[bet1x-backend] Your 11 held OFF: ' . $why);
}
$CRICKET_LIVE = $CRICKET_ENABLED && !$CRICKET_BLOCKED;
$FANTASY_LIVE = $FANTASY_ENABLED && !$FANTASY_BLOCKED;

$LOG_LEVEL = (string) env_get('LOG_LEVEL', 'info');

// --- Fail fast ---
if (count($fatal)) {
    http_response_code(500);
    header('Content-Type: application/json');
    error_log('[bet1x-backend] Refusing to serve — configuration is not production-safe:');
    foreach ($fatal as $msg) error_log('  x ' . $msg);
    echo json_encode(['error' => 'Server misconfigured.']);
    exit;
}

$CONFIG = [
    'NODE_ENV'                 => $NODE_ENV,
    'IS_PRODUCTION'            => $IS_PRODUCTION,
    'APP_SECRET'               => $APP_SECRET,
    'ADMIN_USERNAME'           => $ADMIN_USERNAME,
    'ADMIN_PASSWORD_HASH'      => $ADMIN_PASSWORD_HASH,
    'ADMIN_PASSWORD_PLAINTEXT' => $ADMIN_PASSWORD_PLAINTEXT,
    'SUPERADMIN_USERNAME'           => $SUPERADMIN_USERNAME,
    'SUPERADMIN_PASSWORD_HASH'      => $SUPERADMIN_PASSWORD_HASH,
    'SUPERADMIN_PASSWORD_PLAINTEXT' => $SUPERADMIN_PASSWORD_PLAINTEXT,
    'SUPERADMIN_ACCESS_TOKEN'       => $SUPERADMIN_ACCESS_TOKEN,

    'PHONE_VERIFICATION_REQUIRED'   => $PHONE_VERIFICATION_REQUIRED,
    'FAST2SMS_API_KEY'              => $FAST2SMS_API_KEY,
    'FAST2SMS_ROUTE'                => $FAST2SMS_ROUTE,
    'FAST2SMS_SENDER_ID'            => $FAST2SMS_SENDER_ID,
    'FAST2SMS_MESSAGE_ID'           => $FAST2SMS_MESSAGE_ID,
    'EMAIL_VERIFICATION_REQUIRED'   => $EMAIL_VERIFICATION_REQUIRED,
    'SMTP_HOST'                     => $SMTP_HOST,
    'SMTP_PORT'                     => $SMTP_PORT,
    'SMTP_USER'                     => $SMTP_USER,
    'SMTP_PASSWORD'                 => $SMTP_PASSWORD,
    'SMTP_SENDER_EMAIL'             => $SMTP_SENDER_EMAIL,
    'SMTP_SENDER_NAME'              => $SMTP_SENDER_NAME,
    'OTP_LENGTH'                    => $OTP_LENGTH,
    'OTP_TTL_SECONDS'               => $OTP_TTL_SECONDS,
    'OTP_MAX_ATTEMPTS'              => $OTP_MAX_ATTEMPTS,
    'OTP_RESEND_COOLDOWN_SEC'       => $OTP_RESEND_COOLDOWN_SEC,
    'OTP_MAX_SENDS_PER_DAY'         => $OTP_MAX_SENDS_PER_DAY,
    'DB'                       => $DB,
    'ALLOW_JSON_FALLBACK'      => $ALLOW_JSON_FALLBACK,
    'TRUST_PROXY'              => $TRUST_PROXY,
    'CORS_ORIGINS'             => $CORS_ORIGINS,
    'FORCE_HTTPS'              => $FORCE_HTTPS,
    'SIGNUP_BONUS'             => $SIGNUP_BONUS,
    'ALLOW_AUTO_USER_CREATION' => $ALLOW_AUTO_USER_CREATION,
    'BCRYPT_ROUNDS'            => $BCRYPT_ROUNDS,
    'SESSION_TTL_MS'           => $SESSION_TTL_MS,
    'MIN_BET'                  => $MIN_BET,
    'MAX_BET'                  => $MAX_BET,
    'MIN_WITHDRAWAL'           => $MIN_WITHDRAWAL,
    'COIN_RUPEE_RATE'          => (float) $COIN_RUPEE_RATE,
    'DISABLE_RATE_LIMITS'      => $DISABLE_RATE_LIMITS,
    'AVIATOR_SMART_CRASH'      => $AVIATOR_SMART_CRASH,
    'AVIATOR_HIGH_STAKE_REF'   => $AVIATOR_HIGH_STAKE_REF,
    'AVIATOR_MAX_WIN'          => $AVIATOR_MAX_WIN,
    'TEENPATTI_AUTO_BOT_FILL'  => $TEENPATTI_AUTO_BOT_FILL,
    'TEENPATTI_COMMISSION_PCT' => $TEENPATTI_COMMISSION_PCT,
    'CRON_STALE_SECONDS'         => $CRON_STALE_SECONDS,
    'CRON_HTTP_KEY'              => $CRON_HTTP_KEY,
    'SIGNUP_MAX_PER_IP_PER_DAY'  => $SIGNUP_MAX_PER_IP_PER_DAY,
    'WITHDRAWAL_DAILY_MAX'       => $WITHDRAWAL_DAILY_MAX,
    'WITHDRAWAL_DAILY_COUNT_MAX' => $WITHDRAWAL_DAILY_COUNT_MAX,
    'WITHDRAWAL_REQUIRE_DEPOSIT' => $WITHDRAWAL_REQUIRE_DEPOSIT,
    'WITHDRAWAL_MIN_TURNOVER'    => $WITHDRAWAL_MIN_TURNOVER,
    'CRICKET_ENABLED'          => $CRICKET_ENABLED,
    'CRICKET_LIVE'             => $CRICKET_LIVE,
    'CRICKET_VIRTUAL'          => $CRICKET_VIRTUAL,      // enabled AND allowed (see the production guard)
    'CRICKET_BLOCKED'          => $CRICKET_BLOCKED,
    'FANTASY_LIVE'             => $FANTASY_LIVE,
    'FANTASY_BLOCKED'          => $FANTASY_BLOCKED,
    'LOG_LEVEL'                => $LOG_LEVEL,
    'DATA_DIR'                 => dirname(__DIR__) . '/backend/data',
    'STATIC_ROOT'              => dirname(__DIR__),
];

/** Read one configuration value. */
function cfg($key, $default = null) {
    global $CONFIG;
    return array_key_exists($key, $CONFIG) ? $CONFIG[$key] : $default;
}
