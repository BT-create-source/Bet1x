<?php
/**
 * Player profile: basic account info plus a reconstructed game history (which game, won or lost,
 * exact amount).
 *
 * There is no separate "round result" table anywhere in this codebase — every game logs its money
 * movements into the one shared Transaction ledger (a bet is a Withdrawal row, a win is a Deposit
 * row, each with a descriptive `details` string; see the insert_transaction() call sites in
 * games/*.php, routes/gamesync.php and routes/mines.php). A loss produces no second row of its own
 * — it is simply the absence of a following win — so history here is reconstructed read-only by
 * walking one player's transactions in chronological order and pairing every bet with the next win
 * of the same game (if any) before that game's next bet. This changes nothing about how any game
 * settles or how money moves; it only reinterprets rows already written by that settlement code.
 */

require_once __DIR__ . '/../lib/http.php';
require_once __DIR__ . '/../lib/auth.php';
require_once __DIR__ . '/../lib/helpers.php';

/**
 * Classify one Transaction row's `details` text into a game + event kind, or null if it is not a
 * recognised game transaction (a cashier deposit/withdrawal, an admin adjustment, the signup
 * bonus, etc — all of which use different, unmatched wording).
 */
function profile_classify_txn($details) {
    $details = (string) $details;
    if (stripos($details, 'Aviator Wager') === 0)  return ['game' => 'Vimaan', 'kind' => 'bet'];
    if (stripos($details, 'Aviator Payout') === 0) return ['game' => 'Vimaan', 'kind' => 'win'];
    if (preg_match('/^Color Guess Wager Room:\s*(\S+)/i', $details, $m)) {
        return ['game' => profile_color_room_name($m[1]), 'kind' => 'bet'];
    }
    if (preg_match('/^Color Guess Win Payout Room:\s*(\S+)/i', $details, $m)) {
        return ['game' => profile_color_room_name($m[1]), 'kind' => 'win'];
    }
    if (stripos($details, 'Mines Bet') === 0)      return ['game' => 'Mines', 'kind' => 'bet'];
    if (stripos($details, 'Mines Cash Out') === 0) return ['game' => 'Mines', 'kind' => 'win'];
    if (stripos($details, 'Chicken Road Bet') === 0)      return ['game' => 'Chicken Road', 'kind' => 'bet'];
    if (stripos($details, 'Chicken Road Cash Out') === 0) return ['game' => 'Chicken Road', 'kind' => 'win'];
    if (stripos($details, 'Tower Rush Bet') === 0)        return ['game' => 'Tower Rush', 'kind' => 'bet'];
    if (stripos($details, 'Tower Rush Cash Out') === 0)   return ['game' => 'Tower Rush', 'kind' => 'win'];
    // Astronaut is deliberately absent: a player can hold two bets in one round, which the
    // bet-then-win pairing below cannot untangle. Its rounds come from AstronautBet instead —
    // see profile_astronaut_rounds().
    if (stripos($details, 'Teen Patti Boot') === 0)     return ['game' => 'Teen Patti', 'kind' => 'bet'];
    if (stripos($details, 'Teen Patti Chaal') === 0)    return ['game' => 'Teen Patti', 'kind' => 'bet'];
    if (stripos($details, 'Teen Patti Won Pot') === 0)  return ['game' => 'Teen Patti', 'kind' => 'win'];
    // Cricket. A refund is a return of stake, so it pairs with its bet the same way a win does.
    if (stripos($details, 'Ball by Ball Bet') === 0)    return ['game' => 'Ball by Ball', 'kind' => 'bet'];
    if (stripos($details, 'Ball by Ball Win') === 0)    return ['game' => 'Ball by Ball', 'kind' => 'win'];
    if (stripos($details, 'Ball by Ball Refund') === 0) return ['game' => 'Ball by Ball', 'kind' => 'win'];
    if (stripos($details, 'Your Eleven Entry') === 0)   return ['game' => 'Your 11', 'kind' => 'bet'];
    if (stripos($details, 'Your Eleven Prize') === 0)   return ['game' => 'Your 11', 'kind' => 'win'];
    if (stripos($details, 'Your Eleven Refund') === 0)  return ['game' => 'Your 11', 'kind' => 'win'];
    if (stripos($details, 'Cricket Bet') === 0)         return ['game' => 'Cricket', 'kind' => 'bet'];
    if (stripos($details, 'Cricket Win') === 0)         return ['game' => 'Cricket', 'kind' => 'win'];
    if (stripos($details, 'Cricket Refund') === 0)      return ['game' => 'Cricket', 'kind' => 'win'];
    if (stripos($details, 'Cricket Cash Out') === 0)    return ['game' => 'Cricket', 'kind' => 'win'];
    return null;
}

/** Settled Astronaut bets as history rounds, read from their own table rather than the ledger. */
function profile_astronaut_rounds($username) {
    try {
        $rows = all('SELECT "amount","status","payout","created_at" FROM "AstronautBet"
                     WHERE LOWER("username") = LOWER(?) AND "status" IN (\'won\',\'lost\')
                     ORDER BY "id" DESC LIMIT 200', [$username]);
    } catch (Throwable $e) {
        return [];   // table not migrated yet: no Astronaut history, nothing else affected
    }
    return array_map(function ($b) {
        $won = $b['status'] === 'won';
        return [
            'game'      => 'Astronaut',
            'result'    => $won ? 'won' : 'lost',
            'amount'    => round($won ? (float) $b['payout'] : (float) $b['amount'], 2),
            'stake'     => round((float) $b['amount'], 2),
            'timestamp' => $b['created_at'],
        ];
    }, $rows);
}

function profile_color_room_name($room) {
    switch (strtoupper($room)) {
        case 'SAPRE':  return 'Sapre Color';
        case 'BECONE': return 'Becone Color';
        case 'EMRED':  return 'Emred Color';
        case 'VIP':    return 'VIP Room';
        default:       return 'Color Prediction';
    }
}

/**
 * Turn a chronological list of {game, kind, amount, timestamp, details} rows into resolved
 * rounds. Every bet is paired with the next win of the SAME game that occurs before that game's
 * next fresh bet; an unmatched bet is a loss of its own stake.
 *
 * Teen Patti's "Boot" (once per hand) and "Chaal" (any number of raises within that hand) are both
 * Withdrawals with no shared round number, so consecutive bet rows for Teen Patti are folded
 * together into one hand's stake, split only at the next Boot (the one row type that reliably
 * marks a new hand starting). Every OTHER game is strictly one bet == one round: two bet rows in a
 * row with no win between them are two separate LOSSES, not one round with a doubled-up stake —
 * merging them was the bug behind "a second Aviator loss doesn't get its own row, it just enlarges
 * the first one".
 */
function profile_build_rounds($txns) {
    $byGame = [];
    foreach ($txns as $t) {
        $byGame[$t['game']][] = $t;
    }

    $rounds = [];
    foreach ($byGame as $game => $rows) {
        $n = count($rows);
        $i = 0;
        while ($i < $n) {
            if ($rows[$i]['kind'] !== 'bet') { $i++; continue; }

            $stake = (float) $rows[$i]['amount'];
            $roundAt = $rows[$i]['timestamp'];
            $j = $i + 1;
            while ($game === 'Teen Patti' && $j < $n && $rows[$j]['kind'] === 'bet') {
                if (stripos($rows[$j]['details'], 'Teen Patti Boot') === 0) break;
                $stake += (float) $rows[$j]['amount'];
                $j++;
            }

            $won = null;
            if ($j < $n && $rows[$j]['kind'] === 'win') {
                $won = $rows[$j];
                $j++;
            }

            $rounds[] = [
                'game'      => $game,
                'result'    => $won ? 'won' : 'lost',
                'amount'    => round($won ? (float) $won['amount'] : $stake, 2),
                // The wagered amount, kept separately because 'amount' above is the PAYOUT on a
                // win and the stake only on a loss — so on its own it cannot answer "how much did
                // I bet on this round". Added for the per-game history panels on the game pages;
                // purely an extra field, nothing that already read this array is affected.
                'stake'     => round($stake, 2),
                'timestamp' => $roundAt,
            ];
            $i = $j;
        }
    }

    usort($rounds, function ($a, $b) { return strcmp($b['timestamp'], $a['timestamp']); });
    return $rounds;
}

/**
 * Keep at most $perGame rounds for each game, and at most $total overall, preserving the
 * newest-first order the list already carries.
 *
 * This replaced a flat array_slice() over the whole list, which whichever game the player had been
 * grinding most recently would consume entirely — leaving every other game they had ever played
 * missing from the history section. Purely a display cap: the stats above it are computed from the
 * complete round list and are not affected by anything here.
 */
function profile_cap_per_game($rounds, $perGame, $total) {
    $kept = [];
    $out  = [];
    foreach ($rounds as $r) {
        $game = $r['game'];
        $n = isset($kept[$game]) ? $kept[$game] : 0;
        if ($n >= $perGame) continue;
        $kept[$game] = $n + 1;
        $out[] = $r;
        if (count($out) >= $total) break;
    }
    return $out;
}

function register_profile_routes(Router $app) {
    $app->get('/api/profile', 'require_auth', function (Req $req, Res $res) {
        try {
            $username = $req->auth['username'];
            $user = find_user_ci($username);
            if (!$user) {
                $res->status(404)->json(['error' => 'Account not found.']);
                return;
            }

            // Newest rows, not oldest. With ASC the cap kept a player's FIRST N transactions, so
            // once someone crossed it their recent play stopped reaching this page at all. The
            // list is flipped back into chronological order immediately afterwards, because
            // pairing a bet with the win that follows it only works reading forwards.
            $rows = all(
                'SELECT "details","amount","timestamp" FROM "Transaction" '
                . 'WHERE LOWER("user") = LOWER(?) ORDER BY "timestamp" DESC LIMIT 5000',
                [$username]
            );
            $rows = array_reverse($rows);

            $classified = [];
            foreach ($rows as $r) {
                $cls = profile_classify_txn($r['details']);
                if (!$cls) continue;
                $classified[] = [
                    'game'      => $cls['game'],
                    'kind'      => $cls['kind'],
                    'amount'    => (float) $r['amount'],
                    'timestamp' => $r['timestamp'],
                    'details'   => $r['details'],
                ];
            }

            $rounds = profile_build_rounds($classified);
            $rounds = array_merge($rounds, profile_astronaut_rounds($user['username']));
            // bet1x Originals: one row per round from OriginalsRound (a Blackjack double or split is
            // several stakes in one round, which the ledger pairing above cannot fold together).
            if (function_exists('originals_history_rows')) $rounds = array_merge($rounds, originals_history_rows($user['username']));
            usort($rounds, function ($a, $b) { return strcmp($b['timestamp'], $a['timestamp']); });

            $wins = 0; $losses = 0; $totalWon = 0.0; $totalLost = 0.0;
            foreach ($rounds as $r) {
                if ($r['result'] === 'won') { $wins++; $totalWon += $r['amount']; }
                else { $losses++; $totalLost += $r['amount']; }
            }

            $res->json([
                'success' => true,
                'profile' => [
                    'id'             => (int) $user['id'],
                    'username'       => $user['username'],
                    'email'          => $user['email'],
                    'phone'          => $user['phone'] ?? null,
                    'wallet_balance' => (float) $user['wallet_balance'],
                    // Referral commission wallet — see lib/referral.php. Kept here too (in
                    // addition to GET /api/referral) so the profile card's top balance row can
                    // show it without a second request; the referral code itself, and the full
                    // dashboard, are only fetched when the player actually opens that section.
                    'referral_balance' => (float) ($user['referral_balance'] ?? 0),
                    'member_since'   => $user['created_at'] ?? null,
                ],
                'stats' => [
                    'games_played' => count($rounds),
                    'wins'         => $wins,
                    'losses'       => $losses,
                    'total_won'    => round($totalWon, 2),
                    'total_lost'   => round($totalLost, 2),
                    'net'          => round($totalWon - $totalLost, 2),
                ],
                // Most recent first, capped per game rather than across the whole list, so every
                // game the player has actually played reaches the per-game tabs. Still a profile
                // view, not a full statement.
                'history' => profile_cap_per_game($rounds, 50, 400),
            ]);
        } catch (Throwable $err) {
            fail500($res, $err, 'profile');
        }
    });
}
